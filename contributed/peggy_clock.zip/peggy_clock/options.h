/**************************************************************************************
 * Options for clock
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
 * United States License. See  http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/21/08 - Merged into clock program
 * 6/22/08 - released V2
 * 6/24/08 - tidied comments
 *************************************************************************************/

//------------------------------------------------------------------------------
// Uncomment the following statement to use a Dallas Semiconductor DS1387 to
// keep time.  
//
// The DS1307's I2C pins are driven by the AVR's SCL and SDA pins, and it sends
// interrupts to one of the AVR's PCx pins (which pin is specified in ds1307.h).
// These pins are also used by some of Peggy2's buttons, so either leave those
// buttons off the board, or don't use them while the clock is running.
//
// If this statement is commented out, the program will use one of the AVR's
// timers to keep time, but you will have to set the time whenever you
// turn it on or reset the MPU.  See the comments in ds1307.c and main.c.
//#define DS1307




//------------------------------------------------------------------------------
// Uncomment the following statement to use a light dependent resistor (LDR) to
// control the clock's brightness.  The LDR is connected to PC1 on the MPU as in
// the following diagram.
//
//
//                             PC1                5v
//                              o                 ^
//                   10k        |     +-----+     |
//             +---/\/\/\/\-----+-----| LDR |-----+
//             |                      +-----+
//            ---
//            gnd
//
// You may have to select a different value for the resistor depending upon the
// LDR you use.  10k ohms worked for me.  Note that in a fully configured Peggy
// 2.0 board, there will already be a 5k pullup resistor on PC1.  That will have
// to be removed to allow the LDR to work.  The onboard pullups on Peggy's buttons
// are not really necessary anyway since the MPU can use its own internal pullups.
// If you comment out the following statement then the program will adjust the
// display's brightness by time of day using the todBright[] array defined below.
//#define LDR




//------------------------------------------------------------------------------
#ifndef LDR
#ifndef TODBRIGHT
#define TODBRIGHT
#include <avr/pgmspace.h>
//
// This array is used to adjust the brightness of the display by the time of
// day.  It is used only if LDR, above, is NOT defined.  The brightness will
// change only on the hour.
//
// The array contains pairs of values: {Hour}, {Brightness percent}.  The
// default array contains:
//        5, 50,   8, 100,   20, 50,   23, 1,  255, 255
// meaning that the brightness will go to 50% at 5am, 100% at 8am, 50% at 8pm
// and 1% at 11pm.  You can modify the values to match your needs, and you can
// add or remove pairs of values for more or fewer changes throughout the day.
// The final two values must always be 255.  12 midnight should be entered as 0.
// Valid brightness values are between 1% and 100%.
const char todBright[] PROGMEM = {
	5,    50,
	8,   100,
	20,   50,
	23,    1,
	255, 255
};
#endif
#endif
