/**************************************************************************************
 * Draw an analog clock on a Peggy 2.0 LED peg board from Evil Mad
 * Scientist Labs (see www.evilmadscientist.com).
 *
 * Peggy2 is a very low resolution display device (25x25 pixels) so there
 * are some obvious shortcomings when displaying an analog clock.  For
 * example diagonal lines show an extreme stair-step effect (no, I have no
 * intention of incorporating anti-aliasing techniques to smooth the diagonals).
 * Also, roundoff errors cause the hands to display the same position for, say,
 * 11:15 and 11:16 (it happens only on the quarter hours).  But despite these
 * problems, it makes for an interesting conversation piece hanging on the wall
 *
 * The clock may be driven either by one of the AVR's built-in timers, or
 * by a Dallas Semiconductor DS1307 real time clock chip.  DS1307 breakout
 * boards are available from Sparkfun
 * (http://www.sparkfun.com/commerce/product_info.php?products_id=99#) or
 * Futurlec (http://www.futurlec.com/Mini_DS1307.shtml).  I'm using the
 * Futurlec version, but either one should work.  To make the program use a
 * DS1307, define "DS1307"' in options.h.
 *
 * The DS1307 also maintains the date and provides 64 bytes of battery backed
 * RAM, but those features are not used by this program.
 *
 * The display can be quite bright, especially in a darkened room, so the
 * brightness can be controlled either by a light dependent resistor (LDR)
 * or by time of day.
 *
 * USAGE.
 *-------
 * To set the time, press and hold the button labeled 'ANY' (aka b1).  After
 * about a second, the display will dim and the minute hand will be highlighted.
 * Use the OFF/SELECT button to set the minute hand to the correct position.
 * When the minutes are correct, press and hold the ANY button to highlight the
 * hour hand, then use OFF/SELECT to set the hour.  Note that as the hour hand
 * passes 12:00, AM/PM indicators will appear or disappear at the four corners
 * of the screen.  When you have set the hour hand correctly, press and hold the
 * ANY button to switch back to normal run mode.  If you press and hold the
 * OFF/SELECT button while the clock is in run mode, the clock will switch the LEDs
 * off and put the CPU into a very low power mode to conserve batteries.  Press the
 * ON/RESET button to switch the clock on again.  If you are using a DS1307 RTC
 * chip to maintain the time, the clock will be correct each time you turn it on,
 * if not then you will have to set the time manually.
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
 * United States License. See  http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/17/08 - released
 * 6/18/08 - fix comment typo
 * 6/20/08 - remove unnecessary DS1307GetByte() in setTime(), remove temp var
 *		& fix bug writing second value
 *	   - some formatting & comment changes.
 *	   - reorganize clockUpdate() to minimize hand flicker
 *	   - add code to read light dependent resistor to adjust clock brightness
 *	   - adjust brightness by time of day if an LDR is not available
 *	   - move compile time options to options.h
 * 6/22/08 - released V2
 *************************************************************************************/
#include <avr/io.h> 
#include <avr/interrupt.h> 
#include <avr/sleep.h> 
#include <util/delay.h>
#include <math.h>

#include "options.h"
#include "screen.h"

#ifdef DS1307
#include "ds1307.h"
#endif

#define BUTTON_OFF	PB0
#define BUTTON_1	PC0

#define CLOCKMODE_FIRST			0
#define CLOCKMODE_RUN			0
#define CLOCKMODE_SET_MINUTE		1
#define CLOCKMODE_SET_HOUR		2
#define CLOCKMODE_LAST			2

#define CLOCKBRIGHT_RUN_FACE		LEDFULLON
#define CLOCKBRIGHT_RUN_HOUR		LEDFULLON-1
#define CLOCKBRIGHT_RUN_MINUTE		6
#define CLOCKBRIGHT_RUN_SECOND		3

#define CLOCKBRIGHT_SETM_FACE		2
#define CLOCKBRIGHT_SETM_HOUR		1
#define CLOCKBRIGHT_SETM_MINUTE		LEDFULLON
#define CLOCKBRIGHT_SETM_SECOND		1

#define CLOCKBRIGHT_SETH_FACE		2
#define CLOCKBRIGHT_SETH_HOUR		LEDFULLON
#define CLOCKBRIGHT_SETH_MINUTE		1
#define CLOCKBRIGHT_SETH_SECOND		1

#ifndef DS1307
volatile uint32_t daySecond;
#endif
volatile uint8_t clockMode;
uint8_t hour, minute, second;
uint8_t faceBright   = CLOCKBRIGHT_RUN_FACE;
uint8_t hourBright   = CLOCKBRIGHT_RUN_HOUR;
uint8_t minuteBright = CLOCKBRIGHT_RUN_MINUTE;
uint8_t secondBright = CLOCKBRIGHT_RUN_SECOND;
float brightnessFactor = 1.;

void getBrightness();
void setBrightness();
void clockUpdate();
void clockDrawFace();
void getTime();
void setTime();
void ticToc(uint8_t onOff);
void powerSave();
void init();

/**************************************************************************************
 * Handle level changes on PB0 (connected to the 'off' button)
 *
 * If we are in CLOCKMODE_RUN mode (the clock is running) and the off button is held
 * down for some time, perform a virtual power off.
 * If we are not in CLOCKMODE_RUN mode then this button adjusts the minute or hour
 * hand, depending on the mode we are in.
 *************************************************************************************/
SIGNAL(PCINT0_vect) {
	uint8_t n;

	// Continue handling interrupts
	// so that we don't block the screen driver
	sei();

	// Time how long the button stays down.  Timeout after a count of 100
	for (n=0; n<100; n++) {
		if (PINB & _BV(BUTTON_OFF)) break;
		// NOTE: _delay_xx() functions are implemented as busy loops,
		// so they are affected by the display interrupt rate.
		_delay_ms(2);
	}

	// If we are in run mode and the button was held down
	// for a full count then go into powersave mode.
	if ((clockMode == CLOCKMODE_RUN) && (n > 99)) powerSave();

	// If we are not in run mode and we counted long enough for
	// the click to qualify as a real button press, not just
	// contact bounce, then update either the minute or hour
	// hand, depending on the current mode.  Keep updating
	// as long as the button stays pressed.
	if (n > 3) {
		second = 0;
		switch (clockMode) {
			case CLOCKMODE_SET_MINUTE:
				do {
					minute =  (minute + 1) % 60;
					clockUpdate();
					_delay_ms(10);
				} while (!(PINB & _BV(BUTTON_OFF)));
				break;
			case CLOCKMODE_SET_HOUR:
				do {
					hour = (hour + 1) % 24;
					clockUpdate();
					_delay_ms(10);
				} while (!(PINB & _BV(BUTTON_OFF)));
				break;
			default:
				// shouldn't happen
				break;
		}
	}
}

/**************************************************************************************
 * Handle level changes on PC0 (connected to the 'B1' button).
 * If we are using a DS1307 RTC, then this routine also handles the 1Hz
 * pendulum ticks that come in on DS1307_PCINTX_PIN (currently set to PCINT9,
 * aka PC3, but check ds1307.h).
 *************************************************************************************/
SIGNAL(PCINT1_vect) {
	uint8_t n;

	// Continue handling interrupts
	// so that we don't block the screen driver
	sei();

	// Handle button1 down events (pin is low)
	if (!(PINC & _BV(BUTTON_1))) {
		// Switch off the pendulum
		ticToc(0);
		for (n=0; n<75; n++) {
			// If button is released then break out of the loop
			if (PINC & _BV(BUTTON_1)) break;

			// Slow down the loop
			// NOTE: _delay_xx() functions are implemented as busy loops,
			// so they are affected by the display interrupt rate.
			_delay_ms(2);
		}

		// If the button was held down long enough, or for a full
		// count then cycle to the next clockMode value.
		if (n > 25) {
			switch (++clockMode) {
				default:
					// Shouldn't happen.  force clockMode
					// to CLOCKMODE_RUN if it does.
					clockMode = CLOCKMODE_RUN;
				case CLOCKMODE_RUN:
					// When we reenter run mode, store the time
					// specified by the user
					setTime();
					// restore and face to normal brightness
					clockDrawFace();
					// Switch on the pendulum
					ticToc(1);
					break;
				case CLOCKMODE_SET_HOUR:
				case CLOCKMODE_SET_MINUTE:
					// set the hands and face to show set time mode
					//clockDrawFace();
					clockUpdate();
					break;
					
			}
		} else {
			// If the button was pressed only briefly, or if it was
			// just contact bounce then switch the pendulum on again,
			// assuming we are in run mode.
			if (clockMode == CLOCKMODE_RUN) ticToc(1);
		}

		return;
	}

#ifdef DS1307
	// Did the DS1307 1Hz signal tick?
	if (!(DS1307_INTERRUPT_PORT_IN & _BV(DS1307_INTERRUPT_PIN))) {
		if (clockMode == CLOCKMODE_RUN) clockUpdate();
		return;
	}
#endif
}

#ifndef DS1307
/**************************************************************************************
 * If we're not using a DS1307, then Timer1 generates the pendulum ticks.
 *************************************************************************************/
SIGNAL(TIMER1_COMPA_vect) {

	// Continue handling interrupts
	// so that we don't block the screen driver
	sei();

	if (clockMode == CLOCKMODE_RUN) clockUpdate();
}
#endif	// ndef DS1307

/**************************************************************************************
 * Perform a virtual shutdown.
 * We can't actually power down in software, but we can go into a very low
 * power mode.
 *************************************************************************************/
void
powerSave() {
	cli();			// stop all interrupts
	PORTD = 0;		// All rows off
	sendRow(0,0,0,0);	// All columns off

	// Select power-down mode & go to sleep!
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_enable();
	sleep_cpu();
}

/**************************************************************************************
 * Initialize all hardware and variables if necessary.
 *************************************************************************************/
void
init() {
	// Enable the pullups on the input pins
	PORTB |= _BV(PB0);
	PORTC |= (_BV(PC0) | _BV(PC2) | _BV(PC3));

	// Enable pin change interrupts for ...
	// ... PB0
	PCICR = _BV(PCIE0);
	PCMSK0 = _BV(PCINT0);
	// ... BUTTON_1 (PC0)
	PCICR |= _BV(PCIE1);
	PCMSK1 = _BV(PCINT8);

	// Init ADC on PC1 (ACD1) to read light sensor
	ADCSRA |= (_BV(ADPS2) | _BV(ADPS1) | _BV(ADPS0)); // ADC prescaler = 128
	ADMUX |= _BV(REFS0);		// ADC reference = AVCC
	ADMUX |= _BV(ADLAR);		// Left adjust ADC result (for 8 bit precision)
	ADMUX |= _BV(MUX0);		// Specify ADC channel (ADC1)
	ADCSRA &= ~_BV(ADATE);		// Single conversion mode
	ADCSRA |= _BV(ADEN);		// enable ADC
	ADCSRA |= _BV(ADSC);		// Initiate a conversion

	// Initialize the screen driver routines.
	screenInit();
	clearScreen(0);

	// Enable interrupts
	sei();

#ifdef DS1307
	// If we're using a DS1307 then initialize it.
	DS1307Initialize();
#else
	// If a DS1307 is not available then use TIMER1
	// as the pendulum.
	OCR1A = F_CPU / 1024;
	TCNT1 = 0;
	TCCR1B |= _BV(WGM12);			// CTC mode
	TCCR1B |= (_BV(CS12) | _BV(CS10));	// prescaler = /1024
	TIMSK1 = _BV(OCIE1A); 			// interrupts on compare match
#endif
}

/**************************************************************************************
 * Determine the brightnessFactor by either reading a light dependent resistor (LDR)
 * or by reading the factor from an array indexed by the hour.  The method used
 * is specified in options.h
 *************************************************************************************/
void
getBrightness() {
#ifdef LDR
	// Read the light sensor
	while (ADCSRA & _BV(ADSC));     // Make sure last conversion has finished
	brightnessFactor = (float)ADCH / 255.;
	if (brightnessFactor < .1) brightnessFactor = .1;
	if (brightnessFactor > 1.0) brightnessFactor = 1.0;
	ADCSRA |= _BV(ADSC);		// Initiate another conversion
#else
	uint8_t c, t;
	PGM_P p;

	t = 1;
	p = &todBright[0];
	while ((c=pgm_read_byte(p++)) < 255) {
		if (hour >= c)
			t = pgm_read_byte(p++);
		else
			p++;
	}
	if (t > 99) t = 99;
	if (t < 1) t = 1;
	brightnessFactor = (float)t / 100.;
#endif
}

/**************************************************************************************
 * Set the brightness variables according to the current clockMode and brightnessFactor
 *************************************************************************************/
void
setBrightness() {

	getBrightness();

	// Set the brightness of the hands depending upon the current clockMode.
	// As long as we set faceBright to a value different from the hands, clearScreen
	// will be able to clear everything on the screen while leaving the face alone,
	// which comes in useful in clockUpdate().
	switch (clockMode) {
		default:
		case CLOCKMODE_RUN:
			faceBright   = (CLOCKBRIGHT_RUN_FACE) * brightnessFactor;
			hourBright   = (CLOCKBRIGHT_RUN_HOUR) * brightnessFactor;
			minuteBright = (CLOCKBRIGHT_RUN_MINUTE) * brightnessFactor;
			secondBright = (CLOCKBRIGHT_RUN_SECOND) * brightnessFactor;

			// Don't allow the hands or face to dim to off, also
			// keep the face value different from the hands so that
			// clearScreen(faceBright) works.
			if (hourBright < 1)   hourBright = 1;
			if (minuteBright < 1) minuteBright = 1;
			if (secondBright < 1) secondBright = 1;
			if (faceBright < 2)   faceBright = 2;
			if (faceBright == hourBright) faceBright = hourBright + 1;
			if (faceBright == minuteBright) faceBright = minuteBright + 1;
			if (faceBright == secondBright) faceBright = secondBright + 1;
			break;
		case CLOCKMODE_SET_HOUR:
			faceBright   = CLOCKBRIGHT_SETH_FACE;
			hourBright   = CLOCKBRIGHT_SETH_HOUR;
			minuteBright = CLOCKBRIGHT_SETH_MINUTE;
			secondBright = CLOCKBRIGHT_SETH_SECOND;
			break;
		case CLOCKMODE_SET_MINUTE:
			faceBright   = CLOCKBRIGHT_SETM_FACE;
			hourBright   = CLOCKBRIGHT_SETM_HOUR;
			minuteBright = CLOCKBRIGHT_SETM_MINUTE;
			secondBright = CLOCKBRIGHT_SETM_SECOND;
			break;
	}
}

/**************************************************************************************
 * Draw the clock face minus the hands, basically just a large circle.
 *************************************************************************************/
void
clockDrawFace() {
	uint8_t x, y;

	setBrightness();

	// Draw the face
	// circle algorithm taken from www.cs.unc.edu/com136Lecture7/circle.html
	// center = 12, radius = 12
	setPixel(12, 0, faceBright);
	setPixel(12, 24, faceBright);
	setPixel(0, 12, faceBright);
	setPixel(24, 12, faceBright);
	x=1;
	y=12;	// sqrt(144 - 1) + .5
	while (x < y) {
		setPixel(12+x, 12+y, faceBright);
		setPixel(12+x, 12-y, faceBright);
		setPixel(12-x, 12+y, faceBright);
		setPixel(12-x, 12-y, faceBright);
		setPixel(12+y, 12+x, faceBright);
		setPixel(12+y, 12-x, faceBright);
		setPixel(12-y, 12+x, faceBright);
		setPixel(12-y, 12-x, faceBright);
		x++;
		y=sqrt(144 - (x * x)) + .5;
	}
	if (x == y) {
		setPixel(12+x, 12+y, faceBright);
		setPixel(12+x, 12-y, faceBright);
		setPixel(12-x, 12+y, faceBright);
		setPixel(12-x, 12-y, faceBright);
	}
}

/**************************************************************************************
 * Retrieve the current time and draw hour, minute, and second hands to represent
 * the time.  It's a toss up whether it's quicker to erase the old hands by redrawing
 * them with a brightness of 0, or just to call clearScreen(faceBright), which
 * clears all pixels on the screen which are *not* currently set to the brightness
 * of the face circle.  I use the latter method.  This routine also displays an
 * am/pm indicator, currently a dim dot in each of the corners of the display.
 *************************************************************************************/
void
clockUpdate() {
	float radians;
	uint8_t t;
	uint8_t secx2, secy2, minx2, miny2, hourx2, houry2;

	getTime();

	// Set the brightness of the hands and face according to the light
	// sensor.  Don't waste time redrawing the face if it hasn't
	// changed brightness.
	t = faceBright;
	setBrightness();
	if (t != faceBright) clockDrawFace();

	// Pre calculate the hand end coordinates to minimize the time between
	// clearing the old hands and drawing the new ones.
	// Center = 12,12, minute & second hands = 11 pixels, hour hand = 7 pixels
	radians = second * (M_PI/30);
	secx2 = 12+sin(radians)*11;
	secy2 = 12-cos(radians)*11;
	radians = minute * (M_PI/30);
	minx2 = 12+sin(radians)*11;
	miny2 = 12-cos(radians)*11;
	radians = ((float)hour + (float)minute/60.) * (M_PI/6);
	hourx2 = 12+sin(radians)*7;
	houry2 = 12-cos(radians)*7;

	// clear the hands, leave the face alone.
	clearScreen(faceBright);

	// AM/PM indicator
	if (hour > 11) {
		setPixel(0,  24, secondBright);
		setPixel(24, 24, secondBright);
		setPixel(0,   0, secondBright);
		setPixel(24,  0, secondBright);
	} else {
		setPixel(0,  24, LEDOFF);
		setPixel(24, 24, LEDOFF);
		setPixel(0,   0, LEDOFF);
		setPixel(24,  0, LEDOFF);
	}

	// Draw the hands
	// Center = 12,12, minute & second hands = 11 pixels, hour hand = 7 pixels
	myLine(12, 12, secx2, secy2, secondBright);
	myLine(12, 12, minx2, miny2,  minuteBright);
	myLine(12, 12, hourx2, houry2,  hourBright);

}

/**************************************************************************************
 * Switch the pendulum on (onOff = 1) or off (onOff = 0).
 *************************************************************************************/
void
ticToc(uint8_t onOff) {
#ifdef DS1307
	if (onOff == 0)
		PCMSK1 &= ~_BV(DS1307_PCINTX_PIN);
	else
		PCMSK1 |= _BV(DS1307_PCINTX_PIN);
#else
	if (onOff == 0)
		TIMSK1 &= ~_BV(OCIE1A);
	else
		TIMSK1 |= _BV(OCIE1A);
#endif
}

/**************************************************************************************
 * The user can set the hands to a specific time value.  This routine takes the
 * current hand positions and either 1) converts the values to BCD and stores them
 * in the DS1307, or 2) converts the values to the daySecond and stores that.
 *************************************************************************************/
void
setTime() {
#ifdef DS1307

	DS1307PutByte(0x00, ((second % 10) + ((uint8_t)(second / 10) << 4)));
	DS1307PutByte(0x01, ((minute % 10) + ((uint8_t)(minute / 10) << 4)));
	DS1307PutByte(0x02, ((hour % 10) + ((uint8_t)(hour / 10) << 4)));
#else
	daySecond = ((uint32_t)hour * 3600) + ((uint32_t)minute * 60);
#endif

}

/**************************************************************************************
 * If the current clockMode is CLOCKMODE_RUN then update the global hour, minute,
 * second variables.
 * If we're using a DS1307, then get the current time from it. Otherwise increment
 * the global variable daySecond and convert its value to hours, minutes, and seconds.
 * This routine is called once per second, on each pendulum tick.
 * It's called only from clockUpdate(), so it could, and probably should, be merged
 * into that routine.  It's here only for for symmetry with setTime().
 *************************************************************************************/
void
getTime() {

	if (clockMode == CLOCKMODE_RUN) {
#ifdef DS1307
		uint8_t byte;

		// The DS1307 stores its values in BCD, so we need
		// to convert them to integers to use them.
		// See the DS1307 datasheet for the format of its
		// time registers.
		if (DS1307GetByte(0, &byte) == 0)
			second = (byte & 0x0f) + (((byte & 0x70) >> 4) * 10);
		if (DS1307GetByte(1, &byte) == 0)
			minute = (byte & 0x0f) + (((byte & 0x70) >> 4) * 10);
		if (DS1307GetByte(2, &byte) == 0)
			hour = (byte & 0x0f) + (((byte & 0x30) >> 4) * 10);
#else
		daySecond++;

		daySecond = daySecond % 86400;
		second    = daySecond % 60;
		minute    = (daySecond / 60) % 60;
		hour      = daySecond / 3600;
#endif
	}
}

/**************************************************************************************
 * Initialize and then go to sleep.  Everything is driven by interrupts.
 *************************************************************************************/
int
main() {

	init();

	// Pause indefinitely letting the interrupts do their thing
	set_sleep_mode(SLEEP_MODE_IDLE);
	while (1) sleep_mode();
}
