/**************************************************************************************
 * Routines for communicating with a Dallas Semiconductor DS1307.
 * They use the code in Atmel's application note AVR315 for the low-level
 * I2C communication.
 *
 * DS1307 breakout boards are available from Sparkfun
 * (http://www.sparkfun.com/commerce/product_info.php?products_id=99#) or
 * Futurlec (http://www.futurlec.com/Mini_DS1307.shtml).  I'm using the
 * Futurlec version, but either one should work.
 *
 * The clock program needs a 1Hz signal, which it refers to as the pendulum.
 * A DS1307 can be used to generate the 1Hz signal and also maintain the time, plus
 * it can use its own battery backup to keep the time accurate even when main power
 * is removed.  It also maintains the date and provides 56 bytes of NV ram space, but
 * those features are not used by the clock program.  If a DS1307 is not used then
 * the clock program falls back on one of its own timers to generate the 1Hz pendulum.
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
 * United States License. See  http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/17/08 - released
 * 6/20/08 - tidy comments
 *	   - move pendulum from PC1 to PC3
 *	   - move "#define DS1307" to options.h
 * 6/22/08 - released V2
 * 6/24/08 - tidy comments
 *************************************************************************************/
#include <avr/io.h>

#include "ds1307.h"

/**************************************************************************************
 * Set up the AVR hardware for communicating with the DS1307, and initialize
 * the I2C (referred to as a two-wire interface) routines.  Make sure the
 * DS1307 is generating a 1Hz interrupt to drive the 'pendulum' needed by
 * the clock routines.
 * Enable interrupts before calling this routine.
 *************************************************************************************/
void
DS1307Initialize() {
	uint8_t byte;

	// Enable pin change interrupts for DS1307 interrupt pin
	DS1307_INTERRUPT_PORT_DDR &= ~_BV(DS1307_INTERRUPT_PIN);	// pin must be an input
	DS1307_INTERRUPT_PORT_OUT |= _BV(DS1307_INTERRUPT_PIN);		// enable pullup
	PCICR |= _BV(PCIE1);	// enable PCINT1 interrupts -- handler
				// must be defined in main.c since it handles other pins too.
	PCMSK1 |= _BV(DS1307_PCINTX_PIN);	// monitor level changes on the interrupt pin

	//////////////////////////////////////////////////////////////////
	// NOTE: interrupts must be enabled prior to the following call //
	//////////////////////////////////////////////////////////////////
	TWI_Master_Initialise();

	// Set control reg to output square wave @ 1Hz
	if (DS1307GetByte(0x07, &byte) == 0) {
		if (byte != 0x10) DS1307PutByte(0x07, 0x10);
	}

}
/**************************************************************************************
 * Set the I2C address of the next read or write operation.
 *************************************************************************************/
uint8_t
DS1307SetAddress(uint8_t byteAddr) {
	DS1307MsgBuf[0] = DS1307_ADDR_WRITE;
	DS1307MsgBuf[1] = byteAddr;
	TWI_Start_Transceiver_With_Data(DS1307MsgBuf, 2 );

	// Wait for transmission to complete
	while (TWI_Transceiver_Busy()) {};

	// Check if the last operation was successful
	if (!TWI_statusReg.lastTransOK) {
		// Got an error during the last transmission.  We could use
		// TWI_Get_State_Info() to retrieve TWI status information to
		// determine cause of failure and take appropriate actions. 
		return(1);
	}

	return(0);
}

/**************************************************************************************
 * Retrieve a byte from the DS1307.  The byte is returned in the argument byte,
 * the functions returns 0 if it succeeded, 1 if it failed.
 *************************************************************************************/
uint8_t
DS1307GetNextByte(uint8_t *byte) {
	DS1307MsgBuf[0] = DS1307_ADDR_READ;
	DS1307MsgBuf[1] = 0;
	TWI_Start_Transceiver_With_Data(DS1307MsgBuf, 2);

	// Wait for transmission to complete
	while (TWI_Transceiver_Busy()) {};

	// Check if the last operation was successful
	if (!TWI_statusReg.lastTransOK) {
		// Got an error during the last transmission.  We could use
		// TWI_Get_State_Info() to retrieve TWI status information to
		// determine cause of failure and take appropriate actions. 
		return(1);
	}

	// Get the received data from the transceiver buffer
	TWI_Get_Data_From_Transceiver(DS1307MsgBuf, 2);
	*byte = DS1307MsgBuf[1];

	return(0);
}

/**************************************************************************************
 * Read a byte from the DS1307 at the specified address.
 *************************************************************************************/
uint8_t
DS1307GetByte(uint8_t addr, uint8_t *byte) {

	if (DS1307SetAddress(addr) != 0) return(1);
	if (DS1307GetNextByte(byte) != 0) return(1);

	return(0);
}

/**************************************************************************************
 * Write a byte to the DS1307 at the specified address.
 *************************************************************************************/
uint8_t
DS1307PutByte(uint8_t addr, uint8_t byte) {
	DS1307MsgBuf[0] = DS1307_ADDR_WRITE;
	DS1307MsgBuf[1] = addr;
	DS1307MsgBuf[2] = byte;
	TWI_Start_Transceiver_With_Data(DS1307MsgBuf, 3);

	// Wait for transmission to complete
	while (TWI_Transceiver_Busy()) {};

	// Check if the last operation was successful
	if (!TWI_statusReg.lastTransOK) {
		// Got an error during the last transmission.  We could use
		// TWI_Get_State_Info() to retrieve TWI status information to
		// determine cause of failure and take appropriate actions. 
		return(1);
	}

	return(0);
}
