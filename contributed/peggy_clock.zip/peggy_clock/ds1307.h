/**************************************************************************************
 * Header file for the DS1307 communication routines.
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
 * United States License. See  http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/17/08 - released
 * 6/22/08 - released V2
 *************************************************************************************/
#include "TWI_Master.h"
uint8_t DS1307MsgBuf[TWI_BUFFER_SIZE];

// Define where the DS1307's interrupt pulse is connected to the AVR
// the other DS1307 connections are on the AVR's SDA & SCL pins.
#define DS1307_INTERRUPT_PORT_DDR	DDRC
#define DS1307_INTERRUPT_PORT_OUT	PORTC
#define DS1307_INTERRUPT_PORT_IN	PINC
#define DS1307_INTERRUPT_PIN		PC3
#define DS1307_PCINTX_PIN		PCINT11

// DS1307 has an I2C addr of 01101000, so the client addr byte for reading is
// 11010001 (0xd1), and for writing it's 11010000 (0xd0)
#define DS1307_ADDR_WRITE       0xd0
#define DS1307_ADDR_READ        0xd1

void DS1307Initialize(void);
uint8_t DS1307SetAddress(uint8_t byteAddr);
uint8_t DS1307GetNextByte(uint8_t *byte);
uint8_t DS1307GetByte(uint8_t addr, uint8_t *byte);
uint8_t DS1307PutByte(uint8_t addr, uint8_t byte);
