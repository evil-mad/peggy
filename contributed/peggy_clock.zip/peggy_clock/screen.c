/**************************************************************************************
 * Routines for maintaining a display 'screen' on a Peggy 2.0 LED peg board from
 * Evil Mad Scientist Labs (see www.evilmadscientist.com).
 *
 * The main routine here is the interrupt handler for TIMER0_COMPA interrupts.
 * It updates the LEDs fast enough to maintain a 16 shade grayscale flicker-free
 * 25x25 pixel display.  The external interface is through the functions:
 *
 * void screenInit();
 * void clearScreen (uint8_t i);
 * uint8_t getPixel(int8_t x,int8_t y);
 * void setPixel(int8_t x,int8_t y, uint8_t brightness);
 *
 * See the comments in each routine for usage information.
 * Also provided are some primitive drawing functions derived from
 * Po-Han Lin's 'Extremely Fast Line Algorithm Var C (Addition)':
 *
 * void myLine(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness);
 * void mySquare(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness);
 * void myRect(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness);
 *
 * The TIMER0_COMPA handler owes its design to the code in peggy2_GrayTest.c
 * by Windell H. Oskay (http://www.evilmadscientist.com), though very little of
 * the original code remains.
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * Other than the line-drawing routines, which are copyrighted by Po-Han Lin,
 * as specified by the comments below, this work is licensed under a Creative
 * Commons Attribution-Noncommercial 3.0 United States License.
 * See http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/17/08 - released
 * 6/22/08 - released V2
 * 7/10/08 - fix typo in Windell's name
 *************************************************************************************/
#include <stdlib.h> 
#include <avr/io.h> 
#include <avr/interrupt.h> 
#include <avr/pgmspace.h> 

#include "screen.h"

/**************************************************************************************
 * This is the main routine for updating the display, it is called automatically
 * when timer0 reaches the value in OCR0A.
 *
 * Each invocation illuminates some of the LEDs on the currentRow.  The currentRow
 * is processed GRAYDEPTH times before incrementing the currentRow variable.  Each
 * time it processes the currentRow, it switches on only those LEDs whose
 * brightness value is greater than dutyTimer, which is incremented each time through
 * and wraps back to 0 when it reaches GRAYDEPTH.  So, if GRAYDEPTH is 15 then any
 * LED whose value is 1 will be illuminated 1 time in 15 invocations, any LED whose
 * value is 15 will be illuminated  15 times in 15 invocations.  This allows a
 * limited PWM-type control of LED brightness.
 *
 * Brightness values for each pixel are stored in a compressed format in the
 * screenBuf[][] array, two pixels per byte.  Accessing this array from within this
 * interrupt handler would be too slow and there wouldn't be enough time to do
 * anything else between interrupts, therefore each time the currentRow variable is
 * incremented, the data for the next row are unpacked from screenBuf[][] and stored
 * in the unpacked[] array.  No LED updates are performed during this unpacking cycle.
 * This is roughly equivalent to the horizontal blanking interval in a CRT.  Once the
 * row is stored in unpacked[], access to the data is fast enough that this routine
 * runs quickly enough to allow other code to run while still updating the screen
 * often enough to avoid perceptable flicker.
 *************************************************************************************/
SIGNAL(TIMER0_COMPA_vect) {
	uint8_t col, bit;
	uint8_t a,b,c,d;

	if (dutyTimer > GRAYDEPTH) {
		dutyTimer = 0;

		if (++currentRow > 24) currentRow = 0;

		// Figure out what to send to the row drivers to enable the new current row.
		if (currentRow < 15)
			portdVal =  currentRow + 1;
		else
			portdVal = (currentRow - 14) << 4; 

		// unpack the current row's pixel brightness values
		for (col=0; col<25; col++) unpacked[col] = getPixel(col, currentRow);

	} else {

		a = b = c = d = 0;
		for (col=0, bit=1; col<8; col++, bit=(bit<<1)) {
			if (unpacked[col] > dutyTimer) a |= bit;
			if (unpacked[col+8] > dutyTimer) b |= bit;
			if (unpacked[col+16] > dutyTimer) c |= bit;
		}
		if (unpacked[24] > dutyTimer) d = 0x01;       

		// Switch off all rows while we update the columns.
		PORTD = 0;
		sendRow(a, b, c, d);
		PORTD = portdVal;

		dutyTimer++;
	}
}

/**************************************************************************************
 * Clear the screen.
 *
 * Set any pixel whose value is not i to 0.  If i = 0 then clear entire screen.
 *
 * Don't really need the t variable, but the optimizer produces smaller
 * (& faster?) code this way.
 *************************************************************************************/
void
clearScreen(uint8_t i) {
	uint8_t x, y, t;

	for (y=0; y<25; y++) {
		for (x=0; x<13; x++) {
			t = screenBuf[y][x].odd;
			if (t != i) screenBuf[y][x].odd = LEDOFF;
			t = screenBuf[y][x].even;
			if (t != i) screenBuf[y][x].even = LEDOFF;
		}
	}
}

/**************************************************************************************
 * Send the current row bitmap out to the shift registers using the AVR's
 * hardware SPI port.  It's a shame to have to sit and spin our wheels in
 * busy loops waiting for the SPI transmissions to complete, but we have
 * to turn off all LEDs while we update the shift regs, and we want them
 * to be off for as short an interval as possible, and this turns out to
 * be the most efficient way to do that. Using the SPI transmission complete
 * interrupt actually takes longer due to the interrupt handler overhead.
 * Even though it may free up some CPU cycles for other purposes, the LEDs
 * end up being off longer.
 *************************************************************************************/
void
sendRow (uint8_t a, uint8_t b, uint8_t c, uint8_t d) {

	SPDR = d;
	while (!(SPSR & _BV(SPIF)));
	SPDR = c;
	while (!(SPSR & _BV(SPIF)));
	SPDR = b;
	while (!(SPSR & _BV(SPIF)));
	SPDR = a;
	while (!(SPSR & _BV(SPIF)));
	PORTB |= _BV(LE); PORTB &= ~_BV(LE);	// Latch data to output pins
}

/**************************************************************************************
 * Initialize all ports, timers, and external hardware.
 *
 * The value assigned to OCR0A, below, controls how often the timer triggers a
 * display update.  Larger values slow down the updates and allow more CPU time
 * for user programs, but can cause noticable flicker.  Smaller values update
 * faster and produce a smoother display, but don't leave much time for anything
 * other than driving the display.
 *
 * The calculation to initialize OCR0A below is:
 *
 * F_CPU/(REFRESH_RATE * TIMER0_prescaler * #rows_of_LEDs * GRAYDEPTH)
 *
 * F_CPU is the speed of the CPU clock in Hz and is passed in on the compilation
 * 	line.  It is also used by the avr-libc delay routines.
 * REFRESH_RATE is defined in screen.h.   65 screen updates per second produce a
 * 	reasonably flicker-free display for me. YMMV.
 * The TIMER0_prescaler must match what you set the prescaler value to in TCCR0B,
 * 	below.
 * #rows is a constant 25 for the Peggy2 board.
 * GRAYDEPTH is defined in screen.h and is limited to a maximum of 15 (16 levels of
 * 	gray, where 0=off) since 4 bits are used to store each pixel.  Smaller values
 *	allow either a faster refresh rate or more CPU cycles available for other code.
 *
 *************************************************************************************/
void
screenInit() {
	PORTD = 0;
	DDRD = 0xff;

	// Set SPI & LE pins as outputs
	// NOTE: SS is not used here, but if configured as an input it must be held high.
	DDRB = _BV(CLK) | _BV(SDI) | _BV(SS) | _BV(LE);
	SPCR = _BV(SPE) | _BV(MSTR);	// Enable SPI, Master, CLOCK RATE sck/4
	SPSR = _BV(SPI2X);		// Make that CLOCK RATE sck/2

	// Make sure all columns are off.
	sendRow(0,0,0,0);

	// Set up the display timer
	// See comments above for how OCR0A is defined.  Note that it's
	// done this way (multiple divides) to avoid integer overflow
	// complaints from the compiler.  Forcing the divisors to float
	// avoids accumulating round-off errors from multiple integer
	// operations
	OCR0A = F_CPU / (float)REFRESH_RATE / (float)8 / (float)25 / (float)GRAYDEPTH;
	TCCR0A |= _BV(WGM01);	// CTC mode
	TIMSK0 = _BV(OCIE0A);	// interrupts on compare match
	TCCR0B |= _BV(CS01);	// /8 prescaling.  Change the OCR0A expression if
				// you use a different prescaler value

	// initializing dutyTimer this way ensures that other
	// variables are set up correctly the first time
	// through SIGNAL(TIMER0_COMPA_vect)
	dutyTimer = GRAYDEPTH + 1;
}

/**************************************************************************************
 * Return the brightness value of the pixel at x, y.
 *************************************************************************************/
uint8_t
getPixel(int8_t x,int8_t y) {
	if (x & 0x01)
		return (screenBuf[y][x/2].odd);
	else
		return (screenBuf[y][x/2].even);
}

/**************************************************************************************
 * Set the brightness of the pixel at x, y to 'brightness' (0=off).
 *************************************************************************************/
void
setPixel(int8_t x,int8_t y, uint8_t brightness) {
	if (x & 0x01)
		screenBuf[y][x/2].odd = brightness;
	else
		screenBuf[y][x/2].even = brightness;
}

/*************************************************************************************/
/**************************************************************************************
 * Extremely Fast Line Algorithm Var C (Addition)
 * Copyright 2001-2, By Po-Han Lin
 *
 * Freely useable in non-commercial applications as long as credits 
 * to Po-Han Lin and link to http://www.edepot.com is provided in source 
 * code and can been seen in compiled executable.  Commercial 
 * applications please inquire about licensing the algorithms.
 *
 * Lastest version at http://www.edepot.com/phl.html
 *************************************************************************************/
// The following places a reference to the line drawing algorithm
// author in the binary, as required by the copyright.
const char *LineDrawingCopyright PROGMEM = "Po-Han Lin www.edepot.com";

/*----------------------------------------------------------
 * Draw a line from x,y to x2, y2 at value in the
 * arg brightness
 *--------------------------------------------------------*/
void
myLine(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness) {
	uint8_t yLonger=0;
	int8_t incrementVal, endVal;
	int8_t i;

	int8_t shortLen=y2-y;
	int8_t longLen=x2-x;
	if (abs(shortLen)>abs(longLen)) {
		int8_t swap=shortLen;
		shortLen=longLen;
		longLen=swap;
		yLonger=1;
	}
	
	endVal=longLen;
	if (longLen<0) {
		incrementVal=-1;
		longLen=-longLen;
	} else incrementVal=1;

	double decInc;
	if (longLen==0) decInc=(double)shortLen;
	else decInc=((double)shortLen/(double)longLen);
	double j=0.0;
	if (yLonger) {
		for (i=0;i!=endVal;i+=incrementVal) {
			setPixel(x+(int8_t)j,y+i, brightness);
			j+=decInc;
		}
	} else {
		for (i=0;i!=endVal;i+=incrementVal) {
			setPixel(x+i,y+(int8_t)j, brightness);
			j+=decInc;
		}
	}
}

#ifdef NOT_DEFINED
// These routines are not needed for the clock program.
/*----------------------------------------------------------
 * Draw a square from x,y to x2, y2 at value in the
 * arg brightness
 *--------------------------------------------------------*/
void
mySquare(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness) {
	myLine(x,y,x2,y2,brightness);
	myLine(x2,y2,x2+(y-y2),y2+(x2-x),brightness);
	myLine(x,y,x+(y-y2),y+(x2-x),brightness);
	myLine(x+(y-y2),y+(x2-x),x2+(y-y2),y2+(x2-x),brightness);
}

/*----------------------------------------------------------
 * Draw a rectangle from x,y to x2, y2 at value in the
 * arg brightness
 *--------------------------------------------------------*/
void
myRect(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness) {
	myLine(x,y,x2,y,brightness);
	myLine(x2,y,x2,y2,brightness);
	myLine(x2,y2,x,y2,brightness);
	myLine(x,y2,x,y,brightness);
}
#endif

/**************************************************************************************
 * End of code  Copyright 2001-2, By Po-Han Lin
 *************************************************************************************/
