/**************************************************************************************
 * Display an image on a Peggy 2.0 LED peg board from Evil Mad
 * Scientist Labs (see www.evilmadscientist.com).
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
 * United States License. See  http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/17/08 - released
 * 6/18/08 - add more comments.
 *************************************************************************************/
#include <avr/io.h> 
#include <avr/interrupt.h> 
#include <avr/sleep.h> 
#include <avr/pgmspace.h> 
#include <util/delay.h>

#include "screen.h"

/*
 * The picture data is stored in program memory to conserve RAM.
 * It would be better stored off-chip, perhaps in a 24C32 or some such.
 */
const char l1[25] PROGMEM = {11,11,10, 3, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 7,13,13,13,14,13};
const char l2[25] PROGMEM = {11,11, 8, 3, 1, 1, 1, 1, 1, 1, 1, 1, 4, 5, 4, 1, 2, 2, 1, 3, 6,12,14,13,13};
const char l3[25] PROGMEM = {10,10, 6, 2, 1, 1, 2, 2, 1, 3, 5, 8,13,15,14, 8, 3, 1, 1, 3, 3, 8,14,13,13};
const char l4[25] PROGMEM = {11, 8, 3, 2, 3, 5, 7, 7, 8,13,15,15,15,15,15,15,11, 5, 3, 4, 3, 7,13,13,13};
const char l5[25] PROGMEM = {11, 8, 3, 3, 7,10,13,14,15,15,15,15,15,15,15,15,15,13, 5, 3, 5, 6,12,14,13};
const char l6[25] PROGMEM = {11, 9, 4, 6, 9,11,13,14,14,15,15,15,14,14,15,15,15,13, 7, 4, 6, 5,10,14,13};
const char l7[25] PROGMEM = {12,11, 6, 7, 9,11,11,13,13,14,14,14,13,14,14,14,15,14, 9, 6, 5, 6, 8,14,13};
const char l8[25] PROGMEM = {11,11, 5, 7, 9,11,11,12,12,14,14,14,14,14,14,15,15,13,11, 7, 4, 4, 5, 9,14};
const char l9[25] PROGMEM = {11, 8, 4, 6, 9,13,14,14,13,14,14,15,13,13,14,14,14,10, 8, 6, 3, 5, 3, 7,11};
const char l10[25] PROGMEM = {11, 7, 2, 5, 6, 7, 8,11,11, 9, 8, 7, 4, 7,11,12,11, 9, 5, 5, 4, 6, 4, 6,11};
const char l11[25] PROGMEM = {10, 8, 3, 2, 1, 1, 2, 4, 8, 5, 2, 1, 1, 2, 5, 9,11,10, 4, 3, 4, 6, 5, 6,13};
const char l12[25] PROGMEM = {10, 9, 4, 1, 1, 1, 1, 1, 8, 6, 2, 1, 2, 3, 2, 6,12,11, 4, 3, 3, 6, 9, 9,13};
const char l13[25] PROGMEM = { 9,10, 6, 2, 1, 2, 1, 3,11,11, 5, 3, 3, 6, 7, 7,12,13, 7, 7, 3, 6,12,12,13};
const char l14[25] PROGMEM = {11,11, 8, 6, 5, 4, 4, 7,14,13,11, 7, 6, 9,11,13,14,14, 9,10, 5, 8,11, 9,13};
const char l15[25] PROGMEM = { 9,11, 9, 8, 8, 7, 8,11,14,13,13,11, 9,11,13,14,13, 8, 6,10, 9,11, 7, 8,12};
const char l16[25] PROGMEM = { 9,10,10, 7, 9,11, 8,12,14,13,11,11,14,14,12,11, 9, 5, 5,10,13,13, 9,11,13};
const char l17[25] PROGMEM = {10,11,10, 7, 6, 5, 5, 8,11,11,10, 6, 9,13,11, 7, 6, 6, 6, 8,10,10,12,13,13};
const char l18[25] PROGMEM = {10, 9,11, 7, 2, 2, 4, 2, 2, 4, 7, 8, 4, 5, 5, 6, 7, 8, 5, 5, 8,11,13,13,13};
const char l19[25] PROGMEM = {10,11,10, 9, 3, 2, 4, 2, 2, 5,11,13, 7, 5, 4, 6, 8, 9, 7, 9,12,14,14,13,13};
const char l20[25] PROGMEM = {10,11,11,10, 5, 2, 3, 3, 3, 5, 7, 7, 6, 7, 5, 7, 8, 8, 9,14,13,14,13,13,13};
const char l21[25] PROGMEM = {10,11,11,11, 5, 3, 3, 4, 6, 7, 7, 8, 8, 7, 4, 6, 8, 6,11,14,13,13,13,13,13};
const char l22[25] PROGMEM = {11,11,11,11, 4, 2, 3, 2, 3, 5, 7, 9, 7, 5, 4, 6, 5, 6,13,11,13,13,13,13,13};
const char l23[25] PROGMEM = {11,11,11, 9, 3, 4, 3, 6, 6, 8, 7, 6, 4, 2, 3, 4, 4, 8,15, 8, 9,13,13,13,13};
const char l24[25] PROGMEM = {11,11,10,11, 5, 2, 2, 3, 4, 3, 3, 3, 2, 2, 2, 1, 4,12,15, 7, 4, 9,13,13,13};
const char l25[25] PROGMEM = {11,11,11,11,11, 4, 1, 1, 2, 2, 2, 2, 1, 1, 1, 3, 7,15,15, 7, 3, 5, 8,11,13};
PGM_P pic[25] PROGMEM =  {
	l1,  l2,  l3,  l4,  l5,
	l6,  l7,  l8,  l9,  l10,
	l11, l12, l13, l14, l15,
	l16, l17, l18, l19, l20,
	l21, l22, l23, l24, l25
};

/**************************************************************************************
 * Perform a virtual shutdown.
 * We can't actually power down in software, but we can go into a very low
 * power mode.
 *************************************************************************************/
void
powerSave() {
	cli();                  // stop all interrupts
	PORTD = 0;              // All rows off
	sendRow(0,0,0,0);       // All columns off

	// Select power-down mode & go to sleep!
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_enable();
	sleep_cpu();
}

/**************************************************************************************
 * Handle level changes on PB0 (connected to the 'off' button)
 *************************************************************************************/
SIGNAL(PCINT0_vect) {
uint8_t n;

	// Continue handling interrupts
	// so that we don't block the screen driver
	sei();

	// Time how long the button stays down.  Timeout after a count of 100
	for (n=0; n<100; n++) {
		if (PINB & _BV(PB0)) break;
		// NOTE: _delay_xx() functions are implemented as busy loops,
		// so they are affected by the display interrupt rate.
		_delay_ms(2);
	}

	if (n > 99) powerSave();
}


/**************************************************************************************
 * Initialize and then go to sleep.  Everything is driven by interrupts.
 *************************************************************************************/
int
main() {
	PGM_P p;
	uint8_t x, y;

	// Enable the pullups on the button pins
	PORTB |= _BV(PB0); 
	PORTC |= _BV(PC0);

	// Enable pin change interrupts for PB0
	PCICR = _BV(PCIE0);
	PCMSK0 = _BV(PCINT0);

	// Initialize the screen driver routines. 
	screenInit(); 
	sei();

	// Copy the image from program memory space to the
	// RAM screen buffer array
	for (y=0; y<25; y++) {
		memcpy_P(&p, &pic[y], sizeof(PGM_P));
		for (x=0; x<25; x++) {
			setPixel(x, y, pgm_read_byte(p++));
		}
	}

	// Go to sleep.  Interrupts do all the work.
	set_sleep_mode(SLEEP_MODE_IDLE);
	while (1) sleep_mode();
}
