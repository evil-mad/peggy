/**************************************************************************************
 * Header file for the routines for driving a Peggy 2.0 LED peg board from
 * Evil Mad Scientist Labs (see www.evilmadscientist.com).
 *
 * See screen.c for more info.
 * -----------------------------------------------------------------------------------
 * Geoff Harrison. www.solivant.com. ghov solivant com (put @ and . in the obvious places)
 * -----------------------------------------------------------------------------------
 * This work is licensed under a Creative Commons Attribution-Noncommercial 3.0
 * United States License. See  http://creativecommons.org/licenses/by-nc/3.0/us/
 * -----------------------------------------------------------------------------------
 * 6/17/08 - released
 *************************************************************************************/

/*
 * Definitions for the shift register control pins -- SPI & LE
 */
#define LE    PB1
#define SS    PB2
#define SDI   PB3
#define CLK   PB5

/*
 * # screen updates per second.  If you set this too high the
 * CPU spends all of its time updating the LEDs and has no spare
 * cycles to calculate what to display.  65 works quite well for
 * me, 70 seems to be safe too on a 16Mhz crystal.  I haven't
 * tried a faster rate than that.
 */
#define REFRESH_RATE 70

/*
 * There is a trade off between REFRESH_RATE, above and GRAYDEPTH.
 * You can't increase GRAYDEPTH beyond 15 due to the way pixel values
 * are stored in the screenBuf array (one pixel per 4 bits), but you
 * can reduce it if you don't need all 16 levels of gray.  Reducing
 * it allows a higher REFRESH_RATE or allows more CPU cycles to be
 * spent calculating what to display.
 */
#define GRAYDEPTH	15
#define LEDOFF		0
#define LEDHALFON	8
#define LEDFULLON	GRAYDEPTH

/*
 * Pixels are stored in the screenBuf[][] array two per byte, allowing
 * a maximum of 16 levels of brightness per pixel, including off.
 * The Pixel union allows the code to access either pairs of pixels
 * using the both name, or as individual 4 bit pixels using the
 * even and odd names.
 */
typedef union {
	uint8_t both;
	struct {
		uint8_t even:4;      
		uint8_t odd:4;
	};
} Pixel;

Pixel screenBuf[25][13];

/*
 * The routine that handles the LEDs unpacks a row of data from
 * screenBuf[][] and stores it in the unpacked[] array.  If it
 * didn't do that it would take to long to display a row, leaving
 * little time for other code to run.
 */
uint8_t unpacked[25];

uint8_t currentRow;
uint8_t portdVal;
uint8_t dutyTimer;

void screenInit();
void sendRow (uint8_t a, uint8_t b, uint8_t c, uint8_t d);
void clearScreen (uint8_t i);
uint8_t getPixel(int8_t x,int8_t y);
void setPixel(int8_t x,int8_t y, uint8_t brightness);

void myLine(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness);
void mySquare(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness);
void myRect(int8_t x, int8_t y, int8_t x2, int8_t y2, uint8_t brightness);
