Peggy2Frame, version 1.1
A 16 level greyscale renderer for Windell Oskay's Peggy2.

By Karim Sultan (karimsultan@hotmail.com)

---

REVISIONS
=========
Version 1.0
October 30, 2009
* First release of this class

Version 1.1
November 3, 2009
* Added DisplayImagePlanar()
* Fixed bug with inadvertent x,y swap in DisplayImageRAW() - this may
  corrupt old raw image data, my apologies.  PegEdit will generate
  correct images w/ sketches.

---

Please read "Peggy2Frame.h" for comments and explanation.

To use, drop:

Peggy2Frame.h & Peggy2Frame.cpp into:

[Arduino]\hardware\librairies\Peggy2

and then in your sketch add:

#include <Peggy2Frame.h>

See the examples for usage and read the header for details.

- Karim



