/*
Peggy2Frame Class v1.0
A greyscale supporting frame renderer for Peggy2.

Karim Sultan, October 23 2009.
karimsultan@hotmail.com

This is free software.  Just be fair and adhere to the LGPL 2.1 license,
which says you can use it for your own purposes but can't violate copyright.

PLEASE SEE THE HEADER FILE FOR DETAILS!
*/


// Includes
#include <Peggy2Frame.h>
#include <stdlib.h>
#include <inttypes.h>
#include <math.h>
#include <Peggy2.h>



// Rounds any number to an integer.
int Peggy2Frame::Round(float x)
{
  return ((int)(x > 0.0 ? x + 0.5 : x- 0.5));
}

  
// Constructor
Peggy2Frame::Peggy2Frame()
{
  Initialize();
}

// Destructor
Peggy2Frame::~Peggy2Frame()
{
  // Do nothing
}


// Performs class setup; called by constructor
void Peggy2Frame::Initialize()
{
  // Initialize Peggy2 hardware.  Only needs to be done once.
  planes[0].HardwareInit();
      
  // Pre-calculate the time segments
  // The madness of the casting and rounding is necessary with pow() otherwise
  // it produces unpredictable integer values.
  for (int i=0; i<MAX_PLANES; i++)
    intensity[i] = Round(pow (2.f, (float)i));
}
 

// Draws the planes with varying time slices to create greyscale
void Peggy2Frame::Refresh (void)
{
  for (int i=0; i<MAX_PLANES; i++)
      planes[i].RefreshAll(intensity[i]);
}


// Clears the entire frame
void Peggy2Frame::Clear (void)
{
  for (int i=0; i<MAX_PLANES; i++)
    planes[i].Clear();
}


// Clers a requested plane
void Peggy2Frame::ClearPlane (int plane)
{
  // Validate
  if (plane < 0)
    plane = 0;
  else if (plane >= MAX_PLANES)
    plane = MAX_PLANES - 1;
    
   planes[plane].Clear();
}


void Peggy2Frame::WriteRowPlanar (int y, uint32_t rowdata, int plane)
{    
  // Validate
  if (y < 0) 
    y = 0;
  else if (y >= MAX_HEIGHT)
    y = MAX_HEIGHT - 1;
    
  if (plane < 0)
    plane = 0;
  else if (plane >= MAX_PLANES)
    plane = MAX_PLANES - 1;
    
  planes[plane].WriteRow(y, rowdata);
}


// Plots a point in greyscale
void Peggy2Frame::SetPoint (int x, int y, int grey)
{
  //Validate
  if (grey < 0)
    grey = 0;
  else if (grey > MAX_GREY)
    grey = MAX_GREY;
  
  // Plot point in the correct planes
  for (int i=0; i<MAX_PLANES; i++)
  {
    if ((grey & intensity[i]) == intensity[i])
      planes[i].SetPoint(x,y); 
  }
}


// Plots a point in monochrome
void Peggy2Frame::SetPoint (int x, int y)
{
  SetPoint (x, y, MAX_GREY);
}


// Returns greyscale level (0..15) for point (0 = no point)
int Peggy2Frame::GetPoint (int x, int y)
{
  int greylevel = 0;
  
  // Validate
  if ((x < 0) || (x >= MAX_WIDTH) ||
      (y < 0) || (y >= MAX_HEIGHT))
    return (0);
    
  for (int i=0; i<MAX_PLANES; i++)
    if (planes[i].GetPoint(x,y))
      greylevel += intensity[i];
      
  return(greylevel);
}


// Clears a point
void Peggy2Frame::ClearPoint (int x, int y)
{
  for (int i=0; i<MAX_PLANES; i++)
    planes[i].ClearPoint(x, y);
}


// Draws a line in greyscale
void Peggy2Frame::Line (int x, int y, int xd, int yd, int grey)
{
  int my_grey;
  
  // Validate
  if (grey < 0)
    grey = 0;
  else if (grey > MAX_GREY)
    grey = MAX_GREY;
    
  // Draw line on necessary planes
  for (int i=0; i<MAX_PLANES; i++)
  {
    if ((grey & intensity[i]) == intensity[i])
      planes[i].Line(x, y, xd, yd);
  }
}


// Draws a line in monochrome
void Peggy2Frame::Line (int x, int y, int xd, int yd)
{
  Line(x, y, xd, yd, MAX_GREY);
}


// Draws a line as a Gradient
// NOTE: Oct 23, 2009 : This method is only partially complete. It will work
// only for horizontal lines in a positive direction.  I am optimizing it and
// will update the code once done (probably in a week or two, time permitting).
// - Karim
void Peggy2Frame::LineGradient (int x1, int y1, int g1, int x2, int y2, int g2)
{
  // Validate
  if ((x1 >= MAX_WIDTH && x2 >= MAX_WIDTH) ||
      (y1 >= MAX_HEIGHT && y2 >= MAX_HEIGHT))
    return;
  
  if (g1 < 0) g1=0;
  if (g2 < 0) g2=0;
  if (g1 > MAX_GREY) g1=MAX_GREY;
  if (g2 > MAX_GREY) g2=MAX_GREY;
  
  int dx = abs(x2 -x1);
  int dy = abs(y2 -y1);
  int dg = abs(g2 -g1) + 1;

  // Calculate length of line for gradient scaling
  float len = sqrt(pow(dx,2) +pow(dy,2));    
  int gs = Round(len / (float)dg);
  
  int p1x, p1y, p2x, p2y, i;
  int p1g, p2g, pgc;

  if (dx > dy)
  {
    if (x2>x1) 
    {
      p1x=x1;
      p1y=y1;
      p2x=x2;
      p2y=y2;
      p1g=g1;
      p2g=g2;
    } 
    else {
      p1x=x2;
      p1y=y2;
      p2x=x1;
      p2y=y1;
      p1g=g2;
      p2g=g1;
    }
	
    int y = p1y;
    int x = p1x;
    int gc = p1g;
    int count = 0;
    int increment = p2y > p1y ? 1 : -1;
    
    int gcount = 0;
    int gincrement = g2 > g1 ? 1 : -1;
    
    for (i=0; i<=dx; i++)
    {	
      count += dy;
      if (count > dx)
      {
        count -= dx; 
        y+= increment;
      }		
      
      if (gcount > gs)
      {
        gc += gincrement;
        
        gcount = 0;
      } 
               		
      if (y>=0 && y<25 && x>=0 && x<25) 
		SetPoint(x,y, gc);
      
		x++; 
      if (x>=25) 
		break;

      gcount++;
    }

  }
  else
  {
    if (y2>y1) {
      p1x=x1;
      p1y=y1;
      p2x=x2;
      p2y=y2;
    } 
    else {
      p1x=x2;
      p1y=y2;
      p2x=x1;
      p2y=y1;
    }
    
    int y = p1y;
    int x = p1x;
    int count = 0;
    int increment = p2x > p1x ? 1 : -1;
    for (i=0; i<=dy; i++)
    {	
      count += dx;
      if (count > dy)
      {
        count -= dy; 
        x+= increment;
      }				
      if (y>=0 && y<25 && x>=0 && x<25) 
        SetPoint(x,y);
      y+=1; 
      if (y>=25) break;
    }

  }
} // LineGradient()


// Displays a raw image (ie, 25x25 bytes where each byte is greyscale level).
// These imaegs are represented as char image[25][25].
void Peggy2Frame::DisplayImageRAW (char raw_image[][25])
{
  for (int row=0; row<25; row++)
    for (int col=0; col<25; col++)
      SetPoint(col, row, raw_image[row][col]);
}

// Displays a planar image (ie, 4x25 bytes where each byte is 8 pixels data
// for a given plane.  This means a row is 4 bytes (25 of 32 bits used),
// and since there are 4 planes, there must be: 4 planes * 25 rows * 4 bytes
void Peggy2Frame::DisplayImagePlanar (uint32_t planar_image[][25])
{
  for (int row=0; row<25; row++)
  {
    WriteRowPlanar (row, planar_image[0][row], 0);
    WriteRowPlanar (row, planar_image[1][row], 1);
    WriteRowPlanar (row, planar_image[2][row], 2);
    WriteRowPlanar (row, planar_image[3][row], 3);
  }
}

