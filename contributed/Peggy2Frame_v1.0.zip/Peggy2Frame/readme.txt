Peggy2Frame, version 1.0
A 16 level greyscale renderer.

By Karim Sultan (karimsultan@hotmail.com)
October 23, 2009.

---

Please read "Peggy2Frame.h" for comments and explanation.

To use, drop:

Peggy2Frame.h & Peggy2Frame.cpp into:

[Arduino]\hardware\librairies\Peggy2

and then in your sketch add:

#include <Peggy2Frame.h>

See the examples for usage and read the header for details.

I will add a wiki page in the near future.

- Karim
