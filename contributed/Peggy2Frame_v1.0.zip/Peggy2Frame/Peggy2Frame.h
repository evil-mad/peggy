/*
Peggy2Frame Class v1.0
A greyscale supporting frame renderer for Peggy2.

Karim Sultan, October 23 2009.
karimsultan@hotmail.com

This is free software.  Just be fair and adhere to the LGPL 2.1 license,
which says you can use it for your own purposes but can't violate copyright.

WHAT IS THIS CLASS FOR?
=======================
It creates a frame for Peggy2 consisting of four planes, permitting 16 levels of greyscale.

You can push your data to this frame and have it redrawn to the display.  All greyscale
management is handled by this class.

The first design of this class actually extended the Peggy2 class; revisions found it
easier if it were a separate class that simply used Peggy2 and expose some key methods.

WHAT METHODS ARE AVAILABLE?
===========================
void Clear()                     Clears the all planes
void ClearPlane(p)               Clears plane p
void Refresh()                   Draws the frame
void SetPoint(x, y)              Draws point in monochrome
void SetPoint(x, y, g)           Draws point in greyscale
int  GetPoint(x, y)              Returns the point grey level (0 for none)
void ClearPoint()                Clears a point
void Line(x, y, x2, y2)          Draws line in monochrome
void Line(x, y, x2, y2, g)       Draws line in greyscale
void WriteRowPlanar (y, r, p)    Draws a row on a given plane
void DisplayImageRAW (i[25][25]) Displays a raw image to screen

// NOTE: Not yet complete (being optimized and tested):
void LineGradient (x, y, g, x2, y2, g2)   Draws a gradient line

HOW DO I USE IT?
================
To make this class available to all your sketches, put the .h and .cpp files in:

[Arduino]\hardware\libraries\Peggy2

Then put the following line near the top of your sketch:
#include <Peggy2Frame.h>

HOW DOES IT WORK?
=================
There are some good explanations of greyscale on the Google Code project site, but here's
a quick (and probably poor) one.  LEDs are digital and can only be on or off.  They can
not be between these two states.  However, the human eye is easily fooled.  Using a 
technique known as PWM (pulse width modulation) you can alternate the on/off state
rapidly to create the illusion of an LED at various "dim" levels.  Peggy2 can do this
effectively from 4 levels through 32.  Of course you can go higher, but it becomes
inefficient for the hardware.  16 levels is a good compromise, and allows for 2 pixels
to be represented in one byte:

Pixels per byte, by greyscale level:
 LSB          MSB
 0 1 2 3  4 5 6 7  (one byte)
|0|0|0|0| 0|0|0|0| (eight pixels @ 1 grey each = monochrome)
|0 1|0 1| 0 1|0 1| (four pixels @ 4 greys)
|0 1 2 3 |0 1 2 3| (two pixels @ 16 greys each) 
|0 1 2 3  4|x x x| (one pixel @ 32 greys, with padding)

From the ascii diagram above, you can see that 16 greys at 2 pixels per byte is
a good compromise for image quality and byte usage (in a memory starved environment).
NOTE: This class does not yet handle any image formats other than RAW, which
is one pixel per byte.

To create 16 greys, we use 4 bit planes.  When the frame is refreshed, we
draw each plane, with each successive plane displayed longer than the previous.
If a pixel exists on multiple planes, it will be brighter.  A pixel existing on all
4 planes will have the highest brightness (15) while a pixel existing on no planes
will have brightness 0 and not be drawn.

The following table shows which planes the pixel must exist on in order to be
displayed at a specific greyscale level.

        Greyscale
Plane   0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
    0   -  x  -  x  -  x  -  x  -  x  -  x  -  x  -  x
    1   -  -  x  x  -  -  x  x  -  -  x  x  -  -  x  x
    2   -  -  -  -  x  x  x  x  -  -  -  -  x  x  x  x
    3   -  -  -  -  -  -  -  -  x  x  x  x  x  x  x  x
    
Fortunately, you don't need to worry about this as this class is designed to
abstract the process.  Overloaded high-level methods such as SetPoint(...,Grey), 
Line(...,Grey), and LineGradient will handle stuffing the bit planes.  The Clear
method clears all planes while the Refresh method will redraw all the bit planes
on the display.

The frame class acts as a display driver in that it is the final buffer before
the data is rendered to the Peggy2 device.  Using multiple instances of 
Peggy2Frame is permissible but not desirable due to memory consumption.
A suggested approach is to store your image data (sprites, images, etc...)
in separate buffers, and push to the frame when required.  A series
of helper classes for this purpose (such as sprite routines) are intended
in the future.

PS. For those of you who want to argue that it is "gray" - not "grey",
well, my defense is that I'm Canadian and that's how it's spelled here. 'Nuff said. ;)

POTENTIAL FUTURE REVISIONS FOR THE HACKING INCLINED:
====================================================
* Modify this class to take a parameter establishing the
  greyscale level (2, 4, 8, 16, 32, etc...) to allow the frame
  to have programmable greyscale levels instead of the default
  of 16.
  
* Add an auto-redraw capability that when turned on, will
  update the display automatically (perhaps via the timer
  interrupt) so that the main application does not need to
  constantly call Refresh().  I implemented timer interrupt
  code but removed it because of the blink factor - the
  refreshes were noticeable enough to cause flicker and
  strobing which was painful to the eyes.

* Add in a Pause() method that will freeze the display when
  a button is held or toggle freeze of ths display when a
  button is pressed.
  
* Add in a color-cycling method that rotates the greyscale
  levels up (or down), shifting the bits in their planes to
  allow for special effects like dimming, highlighting, etc...
  
* Drawing primitives and image display methods (both should
  probably be derived or friend classes).

*/


// Includes
#include <inttypes.h>
#include <Peggy2.h>


// Peggy2Frame class; see notes above.
class Peggy2Frame
{
private:
  // Class constants (for class usage)
  static const short MAX_PLANES  = 4;
  
  // Internal variables
  Peggy2             planes[MAX_PLANES];       // Represents 2^4 (16) greyscales.
  int                intensity[MAX_PLANES];    // Time slice per plane

  
  // Rounds any number to an integer.
  int Round(float x);
  
  
public:

  // Class constants (for public usage)
  static const float VERSION     = 1.0f;
  static const short MAX_HEIGHT  = 25;
  static const short MAX_WIDTH   = 25;
  static const short MAX_GREY    = 15;         // Levels are 0 to 15 for 16 total  
  
  // Constructor
  Peggy2Frame();
  
  // Destructor
  ~Peggy2Frame();

  // Performs class setup
  void Initialize();   
  
  // Draws the planes with varying time slices to create greyscale
  void Refresh (void);
  
  // Clears the entire frame
  void Clear (void);  
  
  // Clers a requested plane
  void ClearPlane (int plane);
  
  // Similar to WriteRow, but requires a plane to write to
  void WriteRowPlanar (int y, uint32_t rowdata, int plane);
  
  // Plots a point in greyscale
  void SetPoint (int x, int y, int grey);
  
  // Plots a point in monochrome
  void SetPoint (int x, int y);
  
  // Returns greyscale level (0..15) for point (0 = no point)
  int GetPoint (int x, int y);

  // Clears a point
  void ClearPoint (int x, int y);
  
  // Draws a line in greyscale
  void Line (int x, int y, int xd, int yd, int grey);
  
  // Draws a line in monochrome
  void Line (int x, int y, int xd, int yd);
  
  // Draws a line as a Gradient
  void LineGradient (int x1, int y1, int g1, int x2, int y2, int g2);
  
  // Draws an image of raw data (25x25 with byte=greyscale level)
  // Displays a raw image (ie, 25x25 bytes where each byte is greyscale level.
  void DisplayImageRAW (char raw_image[25][25]);
};
