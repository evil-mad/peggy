PegEdit Application ALPHA for Windows
A peg plotting code outputting application.

Karim Sultan, October 30 2009.
karimsultan@hotmail.com

This is free software.  Just be fair and adhere to the LGPL 2.1 license,
which says you can use it for your own purposes but can't violate copyright.

Peggy2 is by Windell Oskay of Evil Mad Scientist Laboratories.
http://www.evilmadscientist.com

This application is in ALPHA mode: untested and bare bone features.
As always, no warranties are made - nor will ever be made.

PegEdit lets you plot your greyscale LED pictures for Peggy2.

It can generate either the image array of raw data, or the entire
Arduino sketch code (just paste and upload).

Sketches will require the Peggy2Frame class, most likely available
from the same place you obtained this application.

Enjoy!


ABOUT THE SOURCE CODE
=====================
The source is included with the Visual Studio 2008.net solution and project file.

- Karim
