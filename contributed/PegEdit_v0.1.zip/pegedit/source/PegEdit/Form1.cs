﻿/*
PegEdit Application ALPHA for Windows
A peg plotting code outputting application.

Karim Sultan, October 30 2009.
karimsultan@hotmail.com

This is free software.  Just be fair and adhere to the LGPL 2.1 license,
which says you can use it for your own purposes but can't violate copyright.

Peggy2 is by Windell Oskay of Evil Mad Scientist Laboratories.
http://www.evilmadscientist.com

This application is in ALPHA mode: untested and bare bone features.
As always, no warranties are made - nor will ever be made.

PegEdit lets you plot your greyscale LED pictures for Peggy2.

It can generate either the image array of raw data, or the entire
Arduino sketch code (just paste and upload).

Sketches will require the Peggy2Frame class, most likely available
from the same place you obtained this application.

Enjoy!
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PegEdit
{
   public partial class Form1 : Form
   {
      // Members
      private const int PALETTE_WIDTH = 30;
      private const int PALETTE_HEIGHT = 25;

      private const int CANVAS_WIDTH = 500;
      private const int CANVAS_HEIGHT = 500;

      // Flag to clear marquis on first click
      private bool flagFirstClick;

      // The LED type
      private byte ledIndex;

      // Selected grey level (0-15)
      private byte palIndex;

      // Image data buffer
      private byte[,] image = new byte[25, 25];

      // Preset color palette (blues)
      // TODO: Offer different palettes based on LED colour.
      private Color[,] palette = new Color[5,16] 
      {
         // Blue LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x02, 0x20, 0x11),
         System.Drawing.Color.FromArgb(0x04, 0x25, 0x22),
         System.Drawing.Color.FromArgb(0x06, 0x30, 0x33),
         System.Drawing.Color.FromArgb(0x08, 0x35, 0x44),
         System.Drawing.Color.FromArgb(0x0A, 0x40, 0x55),
         System.Drawing.Color.FromArgb(0x0C, 0x45, 0x66),
         System.Drawing.Color.FromArgb(0x0E, 0x50, 0x77),
         System.Drawing.Color.FromArgb(0x10, 0x55, 0x88),
         System.Drawing.Color.FromArgb(0x12, 0x60, 0x99),
         System.Drawing.Color.FromArgb(0x14, 0x65, 0xAA),
         System.Drawing.Color.FromArgb(0x16, 0x70, 0xBB),
         System.Drawing.Color.FromArgb(0x18, 0x75, 0xCC),
         System.Drawing.Color.FromArgb(0x1A, 0x80, 0xDD),
         System.Drawing.Color.FromArgb(0x1C, 0x85, 0xEE),
         System.Drawing.Color.FromArgb(0x1E, 0x90, 0xFF)},

         // Red LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x11, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x22, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x33, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x44, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x55, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x66, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x77, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x88, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x99, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xAA, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xBB, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xCC, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xDD, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xEE, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xFF, 0x00, 0x00)},

         // Green LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x00, 0x11, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x22, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x33, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x44, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x55, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x66, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x77, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x88, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x99, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xAA, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xBB, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xCC, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xDD, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xEE, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xFF, 0x00)},

         // Purple LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x0D, 0x0A, 0x16),
         System.Drawing.Color.FromArgb(0x17, 0x0C, 0x23),
         System.Drawing.Color.FromArgb(0x21, 0x0F, 0x30),
         System.Drawing.Color.FromArgb(0x2b, 0x12, 0x3D),
         System.Drawing.Color.FromArgb(0x35, 0x15, 0x4A),
         System.Drawing.Color.FromArgb(0x3F, 0x18, 0x57),
         System.Drawing.Color.FromArgb(0x49, 0x1B, 0x64),
         System.Drawing.Color.FromArgb(0x53, 0x1E, 0x71),
         System.Drawing.Color.FromArgb(0x5D, 0x21, 0x7E),
         System.Drawing.Color.FromArgb(0x67, 0x24, 0x8B),
         System.Drawing.Color.FromArgb(0x71, 0x27, 0x98),
         System.Drawing.Color.FromArgb(0x7B, 0x2A, 0xA5),
         System.Drawing.Color.FromArgb(0x85, 0x2C, 0xB2),
         System.Drawing.Color.FromArgb(0x8F, 0x2F, 0xBF),
         System.Drawing.Color.FromArgb(0x99, 0x32, 0xCC)},

         // White LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x11, 0x11, 0x11),
         System.Drawing.Color.FromArgb(0x22, 0x22, 0x22),
         System.Drawing.Color.FromArgb(0x33, 0x33, 0x33),
         System.Drawing.Color.FromArgb(0x44, 0x44, 0x44),
         System.Drawing.Color.FromArgb(0x55, 0x55, 0x55),
         System.Drawing.Color.FromArgb(0x66, 0x66, 0x66),
         System.Drawing.Color.FromArgb(0x77, 0x77, 0x77),
         System.Drawing.Color.FromArgb(0x88, 0x88, 0x88),
         System.Drawing.Color.FromArgb(0x99, 0x99, 0x99),
         System.Drawing.Color.FromArgb(0xAA, 0xAA, 0xAA),
         System.Drawing.Color.FromArgb(0xBB, 0xBB, 0xBB),
         System.Drawing.Color.FromArgb(0xCC, 0xCC, 0xCC),
         System.Drawing.Color.FromArgb(0xDD, 0xDD, 0xDD),
         System.Drawing.Color.FromArgb(0xEE, 0xEE, 0xEE),
         System.Drawing.Color.FromArgb(0xFF, 0xFF, 0xFF)},
      };


      // The startup image
      private byte[,] imgMarquis = new byte[25,25]
{
  { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}, // 00
  { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  4,  4,  4,  4,  4,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}, // 01
  { 0,  0,  0,  0,  0,  0,  0,  0,  4,  9,  9,  9,  9,  9,  9,  9,  4,  0,  0,  0,  0,  0,  0,  0,  0}, // 02
  { 0,  0,  0,  0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0,  0,  0,  0}, // 03
  { 0,  0,  0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0,  0,  0}, // 04
  { 0,  0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0,  0}, // 05
  { 0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0}, // 06
  { 0,  0,  0,  4,  9, 15, 15,  8,  0,  8, 15, 15, 15, 15,  8,  0,  8, 15, 15, 15,  9,  4,  0,  0,  0}, // 07
  { 0,  0,  4,  9, 15, 15, 15,  0,  0,  0, 15, 15, 15, 15,  0,  0,  0, 15, 15, 15, 15,  9,  4,  0,  0}, // 08
  { 0,  0,  4,  9, 15, 15, 15,  0,  0,  0, 15, 15, 15, 15,  0,  0,  0, 15, 15, 15, 15,  9,  4,  0,  0}, // 09
  { 0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0}, // 10
  { 0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0}, // 11
  { 0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0}, // 12
  { 0,  4,  9, 15, 15,  0, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  0, 15, 15,  9,  4,  0}, // 13
  { 0,  4,  9, 15, 15,  0,  0,  0,  0, 15, 15,  0,  0,  0, 15, 15,  0,  0,  0,  0, 15, 15,  9,  4,  0}, // 14
  { 0,  0,  4,  9, 15, 15,  0,  0,  0, 15,  8,  0,  0,  0,  8, 15,  0,  0,  0, 15, 15,  9,  4,  0,  0}, // 15
  { 0,  0,  4,  9, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 15, 15, 15,  9,  4,  0,  0}, // 16
  { 0,  0,  0,  4,  9, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0, 15, 15, 15, 15,  9,  0,  0,  0}, // 17
  { 0,  0,  0,  4,  9, 15, 15, 15, 15,  0,  0,  8,  8,  8,  0,  0, 15, 15, 15, 15,  9,  4,  0,  0,  0}, // 18
  { 0,  0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0,  0}, // 19
  { 0,  0,  0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0,  0,  0}, // 20
  { 0,  0,  0,  0,  0,  0,  4,  9, 15, 15, 15, 15, 15, 15, 15, 15, 15,  9,  4,  0,  0,  0,  0,  0,  0}, // 21
  { 0,  0,  0,  0,  0,  0,  0,  0,  4,  9,  9,  9,  9,  9,  9,  9,  4,  0,  0,  0,  0,  0,  0,  0,  0}, // 22  
  { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  4,  4,  4,  4,  4,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}, // 23
  { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0}  // 24
};

      public Form1()
      {
         InitializeComponent();
      }


      void DrawPalette(Graphics gfx)
      {
         // Draw the palette
         int w = PALETTE_WIDTH;
         int h = PALETTE_HEIGHT;

         for (int row = 0; row < 2; row++)
            for (int col = 0; col < 8; col++)
            {
               Brush palBrush = new System.Drawing.SolidBrush(palette[ledIndex, (row * 8) + col]);
               gfx.FillRectangle(palBrush, 515 + (col * w), 10 + (row * h), w, h);
            }

         // Draw frame around selected palette
         Pen palPen = new System.Drawing.Pen(Color.Gold);
         palPen.Width = 2;
         if (palIndex < 8)
            gfx.DrawRectangle(palPen, 515 + (palIndex * w), 10, w, h);
         else
            gfx.DrawRectangle(palPen, 515 + ((palIndex - 8) * w), 10 + h, w, h);
      }


      void DrawPegs(Graphics gfx)
      {
         // Draw canvas.  Pegs are actually 496x496
         Brush canvasBrush = new System.Drawing.SolidBrush(Color.Black);
         gfx.FillRectangle(canvasBrush, 0, 0, 500, 500);



         // Draw pegs
         for (int x = 0; x < 25; x++)
            for (int y = 0; y < 25; y++)
            {
               Pen pegPen = new Pen(Color.DimGray);

               gfx.DrawEllipse(pegPen, x * 20, y * 20, 18, 18);

               Brush pegBrush = new System.Drawing.SolidBrush(palette[ledIndex, image[x, y]]);
               gfx.FillEllipse(pegBrush, x * 20, y * 20, 18, 18);

            }
      }


      protected override void OnPaint(PaintEventArgs paintEvnt)
      {
         // Get the graphics object 
         Graphics gfx = paintEvnt.Graphics;

         DrawPegs(gfx);
         DrawPalette(gfx);
         
      }


      private void Form1_Load(object sender, EventArgs e)
      {
         // Flag to clear marquis on first click
         flagFirstClick = false;

         // Set text box intro
         tbCode.Text=
            "PegEdit v0.1 (Extreme Alpha)\r\n" +
            "October, 2009 by Karim Sultan\r\n" +
            "(karimsultan@hotmail.com)\r\n" +
            "Released under LGPL.  This is "+
            "free software. Be responsible " + 
            "about it.\r\n" +
            "\r\n" +
            "This is a pre-release. It is " +
            "untested and lacks most of its " +
            "intended feature set such as " +
            "sizing, loading, multiple frames " +
            "for animation,etc... It will " +
            "surely crash or fail miserably. " +
            "Its creation adhered to zero " + 
            "software engineering principles.\r\n" +
            "\r\n" +
            "It was rushed out for Halloween 2009! " +
            "Sketches require the Peggy2Frame class " +
            "(which supports 16 greyscale " +
            "level ouput on a Peggy2). " + 
            " Use accordingly. ;)\r\n";
         
         tbCode.Select(0,0);

         // Set default selected greylevel to max
         palIndex = 15;

         // Set load up data to the load image
         for (int x = 0; x < 25; x++)
            for (int y = 0; y < 25; y++)
               image[x,y] = imgMarquis[y,x];

         // Start with Blue LEDs, my perogative as that's what I built! :)
         listLED.SelectedIndex = 0;
      }


      private void btnClear_Click(object sender, EventArgs e)
      {
         ClearImage();
         DrawPegs(this.CreateGraphics());
      }


      private void ClearImage()
      {
         // Setup the array to all empty
         for (int x = 0; x < 25; x++)
            for (int y = 0; y < 25; y++)
               image[x, y] = 0;
      }

      private void listLED_SelectedIndexChanged(object sender, EventArgs e)
      {
         ledIndex = (byte)listLED.SelectedIndex;
         this.Refresh();
      }


      protected override void OnMouseDown(MouseEventArgs e)
      {
         // Clear marquis if this is first mouse click
         if (!flagFirstClick)
         {
            ClearImage();
            this.Refresh();
            flagFirstClick = true;
         }

         base.OnMouseDown(e);
         int x = e.X;
         int y = e.Y;

         // Is this click on the canvas?
         Rectangle rectCanvas = new Rectangle(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
         Rectangle rectPalette = new Rectangle(515, 10, PALETTE_WIDTH * 8, PALETTE_HEIGHT * 2);
         Point p = new Point(x, y);

         if (rectCanvas.Contains(p)) 
         {
            // If left, draw; if right, clear.
            byte g=palIndex;
            if (e.Button == MouseButtons.Right)
               g = 0;

            HandlePeg(x, y, g);
         }
         else if (rectPalette.Contains(p))
            HandlePalette(x, y);
      }


      protected override void OnMouseUp(MouseEventArgs e)
      {
         base.OnMouseUp(e);
      }


      // Manages mouseclick on pegboard canvas
      void HandlePeg (int x, int y, byte grey)
      {
         // Normalized x,y to {(0,0) .. (24,24)}
         int nx, ny;

         // Transform (origin already (0,0) so no translation necessary
         nx = x / (CANVAS_WIDTH / 25);
         ny = y / (CANVAS_HEIGHT / 25);

         // Rare case where x or y can be 25 - due to rectangle.contains method
         // not actually be exclusive with outer border
         if (nx > 24) nx = 24;
         if (ny > 24) ny = 24;

         // Plot point in virtual image
         image[nx, ny] = grey;
         UpdateCode();

         // Draw the peg
         // This is much faster than redrawing entire canvas
         Graphics gfx = this.CreateGraphics();
         Brush pegBrush = new System.Drawing.SolidBrush(palette[ledIndex, image[nx, ny]]);
         gfx.FillEllipse(pegBrush, nx * 20, ny * 20, 18, 18);
      }


      // Manages mouseclick on palette
      void HandlePalette(int x, int y)
      {
         // Normalized x,y to {(0,0) .. (7,1)}
         int nx, ny;

         // Translate to offset from 0,0 instead of palette origin
         nx = (x - 515) / PALETTE_WIDTH;
         ny = ((y - 10) / PALETTE_HEIGHT);
 
         palIndex = (byte)((ny * 8) + nx);

         DrawPalette(this.CreateGraphics() );
      }


      // Renders image as ascii C++ code
      // Note for C#: you must change the array declaraction from [][] to [,]
      void UpdateCode()
      {
         int x, y;
         String code = "";
         
         // Preamble
         if (rbSketch.Checked)
         {
            code +=
              "/*\r\n" +
              "Generated by PegEdit for Peggy2 boards.\r\n" +
              "PegEdit is by Karim Sultan (karimsultan@hotmail.com).\r\n" +
              "Peggy 2 is by Windell Oskay of www.evilmadscientist.com.\r\n" +
              "*/\r\n\r\n" +
              "#include <Peggy2Frame.h>\r\n\r\n";
         }

            
         // Raw image definition
         code +=
         "char image[25][25] =\r\n" +
         "{\r\n";
         
         // Data
         for (y = 0; y < 25; y++)
         {
            for (x = 0; x < 25; x++)
            {
               if (x == 0)
                  code += "  {";

               code += image[y, x].ToString();

               if (x == 24)
                  code += "}";
               else
                  code += ", ";
            }

            // End of row delimiter
            if (y == 24)
               code += "\r\n";
            else
               code += ",\r\n";
         }

         // End
         code +=
         "};\r\n\r\n";

         if (rbSketch.Checked)
         {
            code +=
            "Peggy2Frame screen;\r\n\r\n" +
            "void setup(){}\r\n\r\n" +
            "void loop()\r\n" +
            "{\r\n" +
            "  screen.DisplayImageRAW(image);\r\n" +
            "  while (true) screen.Refresh();\r\n" +
            "}\r\n\r\n";
         }

         tbCode.Text = code;
      }

      private void button1_Click(object sender, EventArgs e)
      {
         Clipboard.SetText(tbCode.Text);
      }

      private void rbSketch_CheckedChanged(object sender, EventArgs e)
      {
         UpdateCode();
      }

      private void rbImageRaw_CheckedChanged(object sender, EventArgs e)
      {
         UpdateCode();
      }

   }  // Class
}  // Namespace
