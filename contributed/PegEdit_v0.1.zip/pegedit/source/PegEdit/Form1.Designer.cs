﻿namespace PegEdit
{
   partial class Form1
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.directoryEntry1 = new System.DirectoryServices.DirectoryEntry();
         this.tbCode = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.button1 = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.listLED = new System.Windows.Forms.ComboBox();
         this.label1 = new System.Windows.Forms.Label();
         this.rbImageRaw = new System.Windows.Forms.RadioButton();
         this.rbSketch = new System.Windows.Forms.RadioButton();
         this.SuspendLayout();
         // 
         // tbCode
         // 
         this.tbCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.tbCode.Location = new System.Drawing.Point(515, 128);
         this.tbCode.Multiline = true;
         this.tbCode.Name = "tbCode";
         this.tbCode.ReadOnly = true;
         this.tbCode.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.tbCode.Size = new System.Drawing.Size(257, 345);
         this.tbCode.TabIndex = 0;
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(515, 111);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(159, 13);
         this.label2.TabIndex = 2;
         this.label2.Text = "Raw image with Arduino sketch:";
         // 
         // button1
         // 
         this.button1.Location = new System.Drawing.Point(677, 103);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(94, 22);
         this.button1.TabIndex = 3;
         this.button1.Text = "Copy to Clpbrd";
         this.button1.UseVisualStyleBackColor = true;
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(515, 76);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(82, 25);
         this.btnClear.TabIndex = 1;
         this.btnClear.Text = "Clear";
         this.btnClear.UseVisualStyleBackColor = true;
         this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
         // 
         // listLED
         // 
         this.listLED.FormattingEnabled = true;
         this.listLED.Items.AddRange(new object[] {
            "Blue LEDs",
            "Red LEDs",
            "Green LEDs",
            "Purple LEDs",
            "White LEDs"});
         this.listLED.Location = new System.Drawing.Point(677, 76);
         this.listLED.Name = "listLED";
         this.listLED.Size = new System.Drawing.Size(94, 21);
         this.listLED.TabIndex = 2;
         this.listLED.SelectedIndexChanged += new System.EventHandler(this.listLED_SelectedIndexChanged);
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(610, 79);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(58, 13);
         this.label1.TabIndex = 7;
         this.label1.Text = "LED Type:";
         // 
         // rbImageRaw
         // 
         this.rbImageRaw.AutoSize = true;
         this.rbImageRaw.Checked = true;
         this.rbImageRaw.Location = new System.Drawing.Point(515, 480);
         this.rbImageRaw.Name = "rbImageRaw";
         this.rbImageRaw.Size = new System.Drawing.Size(129, 17);
         this.rbImageRaw.TabIndex = 8;
         this.rbImageRaw.TabStop = true;
         this.rbImageRaw.Text = "Raw Image Data Only";
         this.rbImageRaw.UseVisualStyleBackColor = true;
         this.rbImageRaw.CheckedChanged += new System.EventHandler(this.rbImageRaw_CheckedChanged);
         // 
         // rbSketch
         // 
         this.rbSketch.AutoSize = true;
         this.rbSketch.Location = new System.Drawing.Point(647, 480);
         this.rbSketch.Name = "rbSketch";
         this.rbSketch.Size = new System.Drawing.Size(127, 17);
         this.rbSketch.TabIndex = 9;
         this.rbSketch.Text = "Include Entire Sketch";
         this.rbSketch.UseVisualStyleBackColor = true;
         this.rbSketch.CheckedChanged += new System.EventHandler(this.rbSketch_CheckedChanged);
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.BackColor = System.Drawing.Color.AliceBlue;
         this.ClientSize = new System.Drawing.Size(784, 500);
         this.Controls.Add(this.rbSketch);
         this.Controls.Add(this.rbImageRaw);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.listLED);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.button1);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.tbCode);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
         this.Name = "Form1";
         this.Text = "PegEdit v0.1 (Alpha)";
         this.Load += new System.EventHandler(this.Form1_Load);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.DirectoryServices.DirectoryEntry directoryEntry1;
      private System.Windows.Forms.TextBox tbCode;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Button button1;
      private System.Windows.Forms.Button btnClear;
      private System.Windows.Forms.ComboBox listLED;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.RadioButton rbImageRaw;
      private System.Windows.Forms.RadioButton rbSketch;
   }
}

