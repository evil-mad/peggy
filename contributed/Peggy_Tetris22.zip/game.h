
/* PEGGY 2.0 RELATED DEFINES */

/* Choose which of these options matches your Peggy LED layout */

/* Your LED Layout  */
/* The game defaults to using the standard Peggy LED Layout with one color across entire grid. 
   However, if you are like me and have a sexy RGBW grid of LEDs the you may want to enable this.
   Note that it can be hard to recognize the edges of the tetrimino's on an RGBW display.
*/
//#define LED_RGBW             // comment this out if you have a standard LED Layout

/* Tetris Playfield size (in tiles) */
/* This is positioned from the top left of the Peggy board. */
#ifdef LED_RGBW
/* Option 1: Tetris playfield set up for a RGBW Peggy setup like mine. */
#define BOARD_WIDTH     (12)
#define BOARD_HEIGHT    (12)
#else 
/* Option 2:  Standard Tetris playfield ratio for a std single color Peggy setup. 
 */
#define BOARD_WIDTH     (15)
#define BOARD_HEIGHT    (25)
#endif  //LED_RGBW


/* Tetris Related Defines */

/*   STC_SHOW_GHOST_PIECE:      define this for showing the shadow piece.     */
//#define STC_SHOW_GHOST_PIECE

/* Initial time delay (in milliseconds) between falling moves */
#define INIT_DELAY_FALL (1000)
#define KEYCHECK_DELAY (150)

/* Score points given by filled rows (we use the original NES * 10)
 * http://tetris.wikia.com/wiki/Scoring */
#define SCORE_1_FILLED_ROW  (400)
#define SCORE_2_FILLED_ROW  (1000)
#define SCORE_3_FILLED_ROW  (3000)
#define SCORE_4_FILLED_ROW  (12000)

/* User gets more score if he uses hard drop. (factor of SCORE_2_FILLED_ROW) */
#define SCORE_DROP_FACTOR (0.05f)
#define SCORE_DROP_WITH_SHADOW_FACTOR (0.01f)

/* User gets points every time he accelerates downfall (factor of SCORE_2_FILLED_ROW) */
#define SCORE_MOVE_DOWN_FACTOR (0.001f)

/* Number of filled rows required to increase the game level */
#define FILLED_ROWS_FOR_LEVEL_UP    (10)

/* The falling delay is multiplied by this factor with every level up */
#define DELAY_FACTOR_FOR_LEVEL_UP   (0.9f)

/*
 * Game error codes
 */
#define GAME_ERROR_NONE         (0)     /* Everything is OK, oh wonders!      */
#define GAME_ERROR_USER_QUITS   (1)     /* The user quits (bored?), our fail  */
#define GAME_ERROR_NO_MEMORY    (-1)    /* Not enough memory                  */
#define GAME_ERROR_NO_VIDEO     (-2)    /* Video system was not initialized   */
#define GAME_ERROR_NO_IMAGES    (-3)    /* Problem loading the image files    */
#define GAME_ERROR_ASSERT       (-100)  /* Something went very very wrong...  */

/* 
 * Game events
 */
#define EVENT_NONE          (0)
#define EVENT_MOVE_DOWN     (1 << 1)
#define EVENT_MOVE_LEFT     (1 << 2)
#define EVENT_MOVE_RIGHT    (1 << 3)
#define EVENT_ROTATE_CW     (1 << 4)    /* rotate clockwise         */
#define EVENT_ROTATE_CCW    (1 << 5)    /* rotate counter-clockwise */
#define EVENT_DROP          (1 << 6)
#define EVENT_PAUSE         (1 << 7)
#define EVENT_RESTART       (1 << 8)
#define EVENT_SHOW_NEXT     (1 << 9)    /* toggle show next tetromino */
#define EVENT_SHOW_SHADOW   (1 << 10)   /* toggle show shadow */

/* Number of tetromino types */
#define TETROMINO_TYPES (7)

/* We are going to store the tetromino cells in a square matrix */
/* of this size (this is the size of the biggest tetromino)     */
#define TETROMINO_SIZE (4)

/* Tetromino definitions (used as indexes: must be between 0 - [TETROMINO_TYPES - 1])
 * http://tetris.wikia.com/wiki/Tetromino */
#define TETROMINO_I     (0)
#define TETROMINO_O     (1)
#define TETROMINO_T     (2)
#define TETROMINO_S     (3)
#define TETROMINO_Z     (4)
#define TETROMINO_J     (5)
#define TETROMINO_L     (6)

/* Tetromino color indexes (must be between 0 - TETROMINO_TYPES) */
#define COLOR_WHITE     (0)     /* Used for effects (if any) */
#define COLOR_CYAN      (1)
#define COLOR_RED       (2)
#define COLOR_BLUE      (3)
#define COLOR_ORANGE    (4)
#define COLOR_GREEN     (5)
#define COLOR_YELLOW    (6)
#define COLOR_PURPLE    (7)

#define NUM_COLORS      (8)     // Total colors used


/* This value used for empty tiles */
#define EMPTY_CELL  (-1)    

// Other Misc: Handy Peggy2 button definitions:
#define selectButton     (0)
#define anyButton        (1)
#define leftButton       (2)
#define downButton       (3)
#define upButton         (4)
#define rightButton      (5)

//Misc
#define TRUE             (1)
#define FALSE            (0)
/*
 * Data structure that holds information about our tetromino blocks
 */
typedef struct StcTetromino {
    int cells[4][4];
    int x;
    int y;
    int size;
    int type;
} StcTetromino;

/*
 * Data structure that holds information about our game *object*
 */
typedef struct StcGame {
    /*
     * Matrix that holds the cells (tilemap)
     */
    int map[BOARD_WIDTH][BOARD_HEIGHT]; // size: 16*12*12=11 //TODO:Make unsigned int

    StcTetromino nextBlock;     /* next tetromino               */
    StcTetromino fallingBlock;  /* current falling tetromino    */
    int errorCode;              /* game error code              */
    unsigned long systemTime;            /* system time in milliseconds  */
    int fall_delay;          /* fall_delay time for falling tetrominoes   */
    int isOver;         /* 1 if the game is over, 0 otherwise   */
    int isPaused;       /* 1 if the game is paused, 0 otherwise */
    int showPreview;    /* 1 if we must show preview tetromino  */
    unsigned long lastFallTime;  /* last time the game moved the falling tetromino */
    int stateChanged;   /* 1 if game state changed, 0 otherwise */
    int scoreChanged;   /* 1 if game score changed, 0 otherwise */

#ifdef STC_SHOW_GHOST_PIECE
    int showShadow;     /* 1 if we must show ghost shadow       */
    int shadowGap;      /* height gap between shadow and falling tetromino */
#endif

    /* Platform specifics & delayed autoshift: http://tetris.wikia.com/wiki/DAS */
    unsigned long delayLeft;
    unsigned long delayRight;
    unsigned long lastTime;
    
    /*
     * Game events are stored in bits in this variable.
     * must be cleared to EVENT_NONE after being used.
     */
    int events;

    /*
     * Statistic data
     */
    struct {
        long score;         /* user score for current game      */
        int lines;          /* total number of lines cleared    */
        int totalPieces;    /* total number of tetrominoes used */
        int level;          /* current game level               */
        int pieces[TETROMINO_TYPES];    /* number of tetrominoes per type */
    } stats;
} StcGame;


//////***** STEEN / DETELE THEESE WHEN you merge files//////////

/*
 * Creates a game and returns a pointer to a valid game object
 * or a NULL pointer in case of error.
 */
StcGame *createGame();

/*
 * Release resources used by the game.
 */
void deleteGame(StcGame *pGame);


