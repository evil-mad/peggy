﻿namespace PegEdit
{
   partial class Form1
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
         this.directoryEntry1 = new System.DirectoryServices.DirectoryEntry();
         this.tbCode = new System.Windows.Forms.TextBox();
         this.btnCopy = new System.Windows.Forms.Button();
         this.btnClear = new System.Windows.Forms.Button();
         this.listLED = new System.Windows.Forms.ComboBox();
         this.label1 = new System.Windows.Forms.Label();
         this.rbImageRaw = new System.Windows.Forms.RadioButton();
         this.btnSave = new System.Windows.Forms.Button();
         this.btnLoad = new System.Windows.Forms.Button();
         this.tbImageName = new System.Windows.Forms.TextBox();
         this.label2 = new System.Windows.Forms.Label();
         this.rbPlanar = new System.Windows.Forms.RadioButton();
         this.lbImages = new System.Windows.Forms.ListBox();
         this.btnDelete = new System.Windows.Forms.Button();
         this.groupBox1 = new System.Windows.Forms.GroupBox();
         this.lblTemp = new System.Windows.Forms.Label();
         this.rbModeMirror = new System.Windows.Forms.RadioButton();
         this.rbModeRotate = new System.Windows.Forms.RadioButton();
         this.rbModeTranslate = new System.Windows.Forms.RadioButton();
         this.btnTransformDown = new System.Windows.Forms.Button();
         this.btnTransformRight = new System.Windows.Forms.Button();
         this.btnTransformLeft = new System.Windows.Forms.Button();
         this.btnTransformUp = new System.Windows.Forms.Button();
         this.cbSketch = new System.Windows.Forms.CheckBox();
         this.groupBox1.SuspendLayout();
         this.SuspendLayout();
         // 
         // tbCode
         // 
         this.tbCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.tbCode.Location = new System.Drawing.Point(-1, 503);
         this.tbCode.Multiline = true;
         this.tbCode.Name = "tbCode";
         this.tbCode.ReadOnly = true;
         this.tbCode.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.tbCode.Size = new System.Drawing.Size(658, 167);
         this.tbCode.TabIndex = 0;
         // 
         // btnCopy
         // 
         this.btnCopy.Location = new System.Drawing.Point(664, 503);
         this.btnCopy.Name = "btnCopy";
         this.btnCopy.Size = new System.Drawing.Size(94, 22);
         this.btnCopy.TabIndex = 7;
         this.btnCopy.Text = "Copy to Clpbrd";
         this.btnCopy.UseVisualStyleBackColor = true;
         this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
         // 
         // btnClear
         // 
         this.btnClear.Location = new System.Drawing.Point(515, 76);
         this.btnClear.Name = "btnClear";
         this.btnClear.Size = new System.Drawing.Size(82, 25);
         this.btnClear.TabIndex = 1;
         this.btnClear.Text = "Clear";
         this.btnClear.UseVisualStyleBackColor = true;
         this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
         // 
         // listLED
         // 
         this.listLED.FormattingEnabled = true;
         this.listLED.Location = new System.Drawing.Point(647, 78);
         this.listLED.Name = "listLED";
         this.listLED.Size = new System.Drawing.Size(109, 21);
         this.listLED.TabIndex = 2;
         this.listLED.SelectedIndexChanged += new System.EventHandler(this.listLED_SelectedIndexChanged);
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(607, 81);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(34, 13);
         this.label1.TabIndex = 7;
         this.label1.Text = "Type:";
         // 
         // rbImageRaw
         // 
         this.rbImageRaw.AutoSize = true;
         this.rbImageRaw.Checked = true;
         this.rbImageRaw.Location = new System.Drawing.Point(664, 536);
         this.rbImageRaw.Name = "rbImageRaw";
         this.rbImageRaw.Size = new System.Drawing.Size(73, 17);
         this.rbImageRaw.TabIndex = 8;
         this.rbImageRaw.TabStop = true;
         this.rbImageRaw.Text = "Raw Data";
         this.rbImageRaw.UseVisualStyleBackColor = true;
         this.rbImageRaw.CheckedChanged += new System.EventHandler(this.rbImageRaw_CheckedChanged);
         // 
         // btnSave
         // 
         this.btnSave.Location = new System.Drawing.Point(515, 373);
         this.btnSave.Name = "btnSave";
         this.btnSave.Size = new System.Drawing.Size(75, 23);
         this.btnSave.TabIndex = 4;
         this.btnSave.Text = "Save";
         this.btnSave.UseVisualStyleBackColor = true;
         this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
         // 
         // btnLoad
         // 
         this.btnLoad.Location = new System.Drawing.Point(599, 373);
         this.btnLoad.Name = "btnLoad";
         this.btnLoad.Size = new System.Drawing.Size(75, 23);
         this.btnLoad.TabIndex = 5;
         this.btnLoad.Text = "Load";
         this.btnLoad.UseVisualStyleBackColor = true;
         this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
         // 
         // tbImageName
         // 
         this.tbImageName.Location = new System.Drawing.Point(599, 344);
         this.tbImageName.Name = "tbImageName";
         this.tbImageName.Size = new System.Drawing.Size(159, 20);
         this.tbImageName.TabIndex = 3;
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(517, 347);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(70, 13);
         this.label2.TabIndex = 13;
         this.label2.Text = "Image Name:";
         // 
         // rbPlanar
         // 
         this.rbPlanar.AutoSize = true;
         this.rbPlanar.Location = new System.Drawing.Point(664, 557);
         this.rbPlanar.Name = "rbPlanar";
         this.rbPlanar.Size = new System.Drawing.Size(55, 17);
         this.rbPlanar.TabIndex = 9;
         this.rbPlanar.TabStop = true;
         this.rbPlanar.Text = "Planar";
         this.rbPlanar.UseVisualStyleBackColor = true;
         this.rbPlanar.CheckedChanged += new System.EventHandler(this.rbPlanar_CheckedChanged);
         // 
         // lbImages
         // 
         this.lbImages.FormattingEnabled = true;
         this.lbImages.Location = new System.Drawing.Point(515, 402);
         this.lbImages.Name = "lbImages";
         this.lbImages.Size = new System.Drawing.Size(242, 95);
         this.lbImages.Sorted = true;
         this.lbImages.TabIndex = 6;
         this.lbImages.SelectedIndexChanged += new System.EventHandler(this.lbImages_SelectedIndexChanged);
         // 
         // btnDelete
         // 
         this.btnDelete.Location = new System.Drawing.Point(683, 373);
         this.btnDelete.Name = "btnDelete";
         this.btnDelete.Size = new System.Drawing.Size(75, 23);
         this.btnDelete.TabIndex = 14;
         this.btnDelete.Text = "Delete";
         this.btnDelete.UseVisualStyleBackColor = true;
         this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
         // 
         // groupBox1
         // 
         this.groupBox1.Controls.Add(this.lblTemp);
         this.groupBox1.Controls.Add(this.rbModeMirror);
         this.groupBox1.Controls.Add(this.rbModeRotate);
         this.groupBox1.Controls.Add(this.rbModeTranslate);
         this.groupBox1.Controls.Add(this.btnTransformDown);
         this.groupBox1.Controls.Add(this.btnTransformRight);
         this.groupBox1.Controls.Add(this.btnTransformLeft);
         this.groupBox1.Controls.Add(this.btnTransformUp);
         this.groupBox1.Location = new System.Drawing.Point(515, 105);
         this.groupBox1.Name = "groupBox1";
         this.groupBox1.Size = new System.Drawing.Size(240, 230);
         this.groupBox1.TabIndex = 15;
         this.groupBox1.TabStop = false;
         // 
         // lblTemp
         // 
         this.lblTemp.Location = new System.Drawing.Point(43, 113);
         this.lblTemp.Name = "lblTemp";
         this.lblTemp.Size = new System.Drawing.Size(150, 67);
         this.lblTemp.TabIndex = 7;
         this.lblTemp.Text = "This space is reserved for the animation controls, which are coming in the next u" +
             "pdate.";
         // 
         // rbModeMirror
         // 
         this.rbModeMirror.AutoSize = true;
         this.rbModeMirror.Location = new System.Drawing.Point(95, 59);
         this.rbModeMirror.Name = "rbModeMirror";
         this.rbModeMirror.Size = new System.Drawing.Size(51, 17);
         this.rbModeMirror.TabIndex = 6;
         this.rbModeMirror.Text = "Mirror";
         this.rbModeMirror.UseVisualStyleBackColor = true;
         // 
         // rbModeRotate
         // 
         this.rbModeRotate.AutoSize = true;
         this.rbModeRotate.Location = new System.Drawing.Point(95, 36);
         this.rbModeRotate.Name = "rbModeRotate";
         this.rbModeRotate.Size = new System.Drawing.Size(57, 17);
         this.rbModeRotate.TabIndex = 5;
         this.rbModeRotate.Text = "Rotate";
         this.rbModeRotate.UseVisualStyleBackColor = true;
         // 
         // rbModeTranslate
         // 
         this.rbModeTranslate.AutoSize = true;
         this.rbModeTranslate.Checked = true;
         this.rbModeTranslate.Location = new System.Drawing.Point(95, 13);
         this.rbModeTranslate.Name = "rbModeTranslate";
         this.rbModeTranslate.Size = new System.Drawing.Size(69, 17);
         this.rbModeTranslate.TabIndex = 4;
         this.rbModeTranslate.TabStop = true;
         this.rbModeTranslate.Text = "Translate";
         this.rbModeTranslate.UseVisualStyleBackColor = true;
         // 
         // btnTransformDown
         // 
         this.btnTransformDown.Location = new System.Drawing.Point(32, 56);
         this.btnTransformDown.Name = "btnTransformDown";
         this.btnTransformDown.Size = new System.Drawing.Size(24, 23);
         this.btnTransformDown.TabIndex = 3;
         this.btnTransformDown.Text = "↓";
         this.btnTransformDown.UseVisualStyleBackColor = true;
         this.btnTransformDown.Click += new System.EventHandler(this.btnTransformDown_Click);
         // 
         // btnTransformRight
         // 
         this.btnTransformRight.Location = new System.Drawing.Point(58, 33);
         this.btnTransformRight.Name = "btnTransformRight";
         this.btnTransformRight.Size = new System.Drawing.Size(24, 23);
         this.btnTransformRight.TabIndex = 2;
         this.btnTransformRight.Text = "→";
         this.btnTransformRight.UseVisualStyleBackColor = true;
         this.btnTransformRight.Click += new System.EventHandler(this.btnTransformRight_Click);
         // 
         // btnTransformLeft
         // 
         this.btnTransformLeft.Location = new System.Drawing.Point(6, 33);
         this.btnTransformLeft.Name = "btnTransformLeft";
         this.btnTransformLeft.Size = new System.Drawing.Size(24, 23);
         this.btnTransformLeft.TabIndex = 1;
         this.btnTransformLeft.Text = "←";
         this.btnTransformLeft.UseVisualStyleBackColor = true;
         this.btnTransformLeft.Click += new System.EventHandler(this.btnTransformLeft_Click);
         // 
         // btnTransformUp
         // 
         this.btnTransformUp.Location = new System.Drawing.Point(32, 13);
         this.btnTransformUp.Name = "btnTransformUp";
         this.btnTransformUp.Size = new System.Drawing.Size(24, 23);
         this.btnTransformUp.TabIndex = 0;
         this.btnTransformUp.Text = "↑";
         this.btnTransformUp.UseVisualStyleBackColor = true;
         this.btnTransformUp.Click += new System.EventHandler(this.btnTransformUp_Click);
         // 
         // cbSketch
         // 
         this.cbSketch.AutoSize = true;
         this.cbSketch.Location = new System.Drawing.Point(663, 581);
         this.cbSketch.Name = "cbSketch";
         this.cbSketch.Size = new System.Drawing.Size(99, 17);
         this.cbSketch.TabIndex = 16;
         this.cbSketch.Text = "Arduino Sketch";
         this.cbSketch.UseVisualStyleBackColor = true;
         this.cbSketch.CheckedChanged += new System.EventHandler(this.cbSketch_CheckedChanged);
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.BackColor = System.Drawing.Color.AliceBlue;
         this.ClientSize = new System.Drawing.Size(765, 670);
         this.Controls.Add(this.cbSketch);
         this.Controls.Add(this.groupBox1);
         this.Controls.Add(this.btnDelete);
         this.Controls.Add(this.lbImages);
         this.Controls.Add(this.rbPlanar);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.tbImageName);
         this.Controls.Add(this.btnLoad);
         this.Controls.Add(this.btnSave);
         this.Controls.Add(this.rbImageRaw);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.listLED);
         this.Controls.Add(this.btnClear);
         this.Controls.Add(this.btnCopy);
         this.Controls.Add(this.tbCode);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
         this.Name = "Form1";
         this.Text = "PegEdit v0.1 (Alpha)";
         this.Load += new System.EventHandler(this.Form1_Load);
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler (this.Form1_Closing);
         this.groupBox1.ResumeLayout(false);
         this.groupBox1.PerformLayout();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.DirectoryServices.DirectoryEntry directoryEntry1;
      private System.Windows.Forms.TextBox tbCode;
      private System.Windows.Forms.Button btnCopy;
      private System.Windows.Forms.Button btnClear;
      private System.Windows.Forms.ComboBox listLED;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.RadioButton rbImageRaw;
      private System.Windows.Forms.Button btnSave;
      private System.Windows.Forms.Button btnLoad;
      private System.Windows.Forms.TextBox tbImageName;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.RadioButton rbPlanar;
      private System.Windows.Forms.ListBox lbImages;
      private System.Windows.Forms.Button btnDelete;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Button btnTransformDown;
      private System.Windows.Forms.Button btnTransformRight;
      private System.Windows.Forms.Button btnTransformLeft;
      private System.Windows.Forms.Button btnTransformUp;
      private System.Windows.Forms.RadioButton rbModeMirror;
      private System.Windows.Forms.RadioButton rbModeRotate;
      private System.Windows.Forms.RadioButton rbModeTranslate;
      private System.Windows.Forms.CheckBox cbSketch;
      private System.Windows.Forms.Label lblTemp;
   }
}

