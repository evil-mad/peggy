﻿/*
 * LEDPalette Class
 * Karim Sultan (karimsultan@hotmail.com)
 * October 2009
 * 
 * This class represents PegEdit palettes mimicking LED sets
 * compatible with Windell Oskay's excellent Peggy2.
 * 
 * Free software under LGPL 2.1.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PegEdit
{
   /// <summary>
   /// Represents a palette (16 shades) of a particular LED set.
   /// </summary>
   class LEDPalette
   {
      // Members
      public int ColorIndex { get; set; }
      public int LEDIndex { get; set; }

      private const int MAX_SHADES = 16;

      // Preset color palette name strings
      private string[] PaletteNames = new string[5]
      {
         "Blue LEDs",
         "Red LEDs",
         "Green LEDs",
         "Purple LEDs",
         "White LEDs"
      };

      // Preset palettes
      private Color[,] palette = new Color[5, 16] 
      {
         // Blue LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x02, 0x20, 0x11),
         System.Drawing.Color.FromArgb(0x04, 0x25, 0x22),
         System.Drawing.Color.FromArgb(0x06, 0x30, 0x33),
         System.Drawing.Color.FromArgb(0x08, 0x35, 0x44),
         System.Drawing.Color.FromArgb(0x0A, 0x40, 0x55),
         System.Drawing.Color.FromArgb(0x0C, 0x45, 0x66),
         System.Drawing.Color.FromArgb(0x0E, 0x50, 0x77),
         System.Drawing.Color.FromArgb(0x10, 0x55, 0x88),
         System.Drawing.Color.FromArgb(0x12, 0x60, 0x99),
         System.Drawing.Color.FromArgb(0x14, 0x65, 0xAA),
         System.Drawing.Color.FromArgb(0x16, 0x70, 0xBB),
         System.Drawing.Color.FromArgb(0x18, 0x75, 0xCC),
         System.Drawing.Color.FromArgb(0x1A, 0x80, 0xDD),
         System.Drawing.Color.FromArgb(0x1C, 0x85, 0xEE),
         System.Drawing.Color.FromArgb(0x1E, 0x90, 0xFF)},

         // Red LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x38, 0x0A, 0x0A),
         System.Drawing.Color.FromArgb(0x3C, 0x0A, 0x0F),
         System.Drawing.Color.FromArgb(0x40, 0x0A, 0x1A),
         System.Drawing.Color.FromArgb(0x44, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x55, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x66, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x77, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x88, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0x99, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xAA, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xBB, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xCC, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xDD, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xEE, 0x00, 0x00),
         System.Drawing.Color.FromArgb(0xFF, 0x00, 0x00)},

         // Green LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x00, 0x38, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x3C, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x40, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x44, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x55, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x66, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x77, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x88, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0x99, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xAA, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xBB, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xCC, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xDD, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xEE, 0x00),
         System.Drawing.Color.FromArgb(0x00, 0xFF, 0x00)},

         // Purple LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x25, 0x0A, 0x16),
         System.Drawing.Color.FromArgb(0x29, 0x0C, 0x23),
         System.Drawing.Color.FromArgb(0x2D, 0x0F, 0x30),
         System.Drawing.Color.FromArgb(0x31, 0x12, 0x3D),
         System.Drawing.Color.FromArgb(0x35, 0x15, 0x4A),
         System.Drawing.Color.FromArgb(0x3F, 0x18, 0x57),
         System.Drawing.Color.FromArgb(0x49, 0x1B, 0x64),
         System.Drawing.Color.FromArgb(0x53, 0x1E, 0x71),
         System.Drawing.Color.FromArgb(0x5D, 0x21, 0x7E),
         System.Drawing.Color.FromArgb(0x67, 0x24, 0x8B),
         System.Drawing.Color.FromArgb(0x71, 0x27, 0x98),
         System.Drawing.Color.FromArgb(0x7B, 0x2A, 0xA5),
         System.Drawing.Color.FromArgb(0x85, 0x2C, 0xB2),
         System.Drawing.Color.FromArgb(0x8F, 0x2F, 0xBF),
         System.Drawing.Color.FromArgb(0x99, 0x32, 0xCC)},

         // White LEDs
      {  Color.Black,
         System.Drawing.Color.FromArgb(0x39, 0x39, 0x39),
         System.Drawing.Color.FromArgb(0x3E, 0x3E, 0x3E),
         System.Drawing.Color.FromArgb(0x44, 0x44, 0x44),
         System.Drawing.Color.FromArgb(0x4A, 0x4A, 0x4A),
         System.Drawing.Color.FromArgb(0x55, 0x55, 0x55),
         System.Drawing.Color.FromArgb(0x66, 0x66, 0x66),
         System.Drawing.Color.FromArgb(0x77, 0x77, 0x77),
         System.Drawing.Color.FromArgb(0x88, 0x88, 0x88),
         System.Drawing.Color.FromArgb(0x99, 0x99, 0x99),
         System.Drawing.Color.FromArgb(0xAA, 0xAA, 0xAA),
         System.Drawing.Color.FromArgb(0xBB, 0xBB, 0xBB),
         System.Drawing.Color.FromArgb(0xCC, 0xCC, 0xCC),
         System.Drawing.Color.FromArgb(0xDD, 0xDD, 0xDD),
         System.Drawing.Color.FromArgb(0xEE, 0xEE, 0xEE),
         System.Drawing.Color.FromArgb(0xFF, 0xFF, 0xFF)},
      };



      /*
       * 
       * PUBLIC METHODS
       * 
       */

      /// <summary>
      /// Constructor.
      /// </summary>
      public LEDPalette()
      {
         // Default to max shade
         ColorIndex = MAX_SHADES - 1;

         // Default to blue... why?  Because I built the board in blue! :)
         LEDIndex = 0;
      }


      /// <summary>
      /// Determines the string name of the current LED set (palette).
      /// </summary>
      /// <returns>The name as a string</returns>
      public string GetCurrentLEDSetName()
      {
         return (PaletteNames[LEDIndex]);
      }


      /// <summary>
      /// Provides a list of all the available LED sets, allowing them
      /// to be shown in a list as well as for selection by name.
      /// </summary>
      /// <returns>A string[] of the LED set names.</returns>
      public string[] GetAllLedSetNames()
      {
         return (PaletteNames);
      }


      /// <summary>
      /// Given a particular LED set name, selects the related palette.
      /// An invalid name results in the default palette.
      /// </summary>
      /// <param name="name">A valid LED set (palette) name.  See GetLedSetNames().</param>
      public void SetPaletteByName(string name)
      {
         int count = 0;
         bool found = false;

         // Search array for LED set name
         while ((!found) || (count >= PaletteNames.Length))
         {
            if (name == PaletteNames[count])
            {
               LEDIndex = count;
               found = true;
            }
            else count++;
         }

         // Set to default LED set if not found
         if (!found) LEDIndex = 0;
      }


      /// <summary>
      /// Gets the current color, active in the palette.  Based on the 
      /// current LED set (LEDIndex) and the current color index (ColorIndex).
      /// </summary>
      /// <returns>A System.Drawing.Color object.</returns>
      public Color GetColor()
      {
         return (palette[LEDIndex, ColorIndex]);
      }


      /// <summary>
      /// Determines the color value of a swatch in the current palette.
      /// IE, for LED set x, at index value i, the color is c.
      /// </summary>
      /// <param name="swatch">A valid index into the active palette.</param>
      /// <returns>A System.Drawing.Color object.</returns>
      public Color GetColorAt(int swatch)
      {
         // Validate
         if (swatch > MAX_SHADES - 1) swatch = MAX_SHADES - 1;
         else if (swatch < 0) swatch = 0;

         return (palette[LEDIndex, swatch]);
      }

   } // class
} // namespace
