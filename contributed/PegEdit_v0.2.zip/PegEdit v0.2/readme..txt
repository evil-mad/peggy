PegEdit v0.2 Application for Windows
A peg plotting code outputting application.

Karim Sultan, October 30 2009.
karimsultan@hotmail.com

This is free software.  Just be fair and adhere to the LGPL 2.1 license,
which says you can use it for your own purposes but can't violate copyright.

Peggy2 is by Windell Oskay of Evil Mad Scientist Laboratories.
http://www.evilmadscientist.com

PegEdit lets you plot your greyscale LED pictures for Peggy2.

It can generate either the image array of raw data, or the entire
Arduino sketch code (just paste and upload).

Sketches will require the Peggy2Frame class, most likely available
from the same place you obtained this application.

Enjoy!

REVISIONS
=========
 Version 0.1 
 October  30 2009, Karim Sultan
 * Pre-Release (Alpha)
 * Untested and unfinished but functional
 * Released under LGPL

 
 Version 0.2
 November 3 2009, Karim Sultan
 * Added local image repository (XML database)
 * Added support for Save, Load and Delete
 * Added images list of saved images
 * Added support for Planar images (4 planes x 25 rows x 4 bytes)
 * Added sketch output for Planar
 * Added Right Mouse button support for zeroing cells (erasing)
 * Added image shifting (left, right, up, down) in translation mode
 * Added image rotating (90CW, 90CCW, 180) in rotate mode
 * Added image flipping (horizontal, vertical) in mirror mode
 * Added dirty flag check on Load image
 * Added dirty flag check on application exit
 * Prepped engine for animations (next version)
 * Abstracted image management to PegImage class
 * Added PegDB class to handle the XML file with image data and preferences
 * Moved palette management to LEDPalette class
 * Pallettes now load from LEDPalette object on the fly, making 
   customization of LED Sets very simple (add your own for different colors)
 * Changed Marquis / added default image to image database
 * Images now save as Base64; you can decode them externally if desired
 * Added nifty "Peg Edit" image as the new "marquis" (you have to load it though)
 * Added optimized double buffering - no more flicker!
 * Added support for saving / loading user preferences (like LED set, etc...)
 * Fixed accidental error causing v0.1 to not plot more than once
   when mouse was down... annoying!
 * Fixed low level shades on some palette which were too dark to show up
 * Fixed several minor (trivial/cosmetic) bugs
 * Changed output of RAW image to y rows with x columns (to read easier)
 * Corrected a swapped row,column index to image array in PegEdit
 * Corrected same swapped row,column index in Peggy2Frame
 * NOTE: This may cause backwards compatibility issues but hopefully
   the impact is trivial to non-existent. (It was an alpha...)
 * Removed alpha banner - app is now a stable beta

